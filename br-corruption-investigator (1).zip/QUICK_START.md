# Guia de Início Rápido - Investigador de Corrupção Política

## 🚀 Começando em 5 Minutos

### 1. Acessar o Dashboard

```
URL: https://brasilcorrupt-dz2pgana.manus.space/admin
```

### 2. Carregar Dados de Demonstração

1. Clique no botão verde **"Carregar Dados Demo"** na seção de Configurações
2. Aguarde o carregamento (normalmente 2-5 segundos)
3. Você verá as estatísticas atualizadas com dados de exemplo

**Dados Carregados:**
- 3 Servidores Públicos
- 3 Empresas Fornecedoras
- 3 Contratos Públicos
- 2 Candidatos Eleitorais
- 2 Doações de Campanha
- 3 Alertas de Padrões Suspeitos

### 3. Explorar o Sistema

**Dashboard Principal:**
```
URL: https://brasilcorrupt-dz2pgana.manus.space/dashboard
```
- Barra de busca para CPF/CNPJ/nome
- Estatísticas gerais do sistema
- Links para outras seções

**Visualização de Grafos:**
```
URL: https://brasilcorrupt-dz2pgana.manus.space/graph
```
- Grafo interativo mostrando conexões
- Clique em nós para ver detalhes
- Zoom, pan e filtros disponíveis

**Busca de Entidades:**
```
URL: https://brasilcorrupt-dz2pgana.manus.space/search?q=12345678901
```
- Resultados detalhados de servidores, empresas, candidatos
- Alertas associados
- Conexões e relacionamentos

---

## 📊 Dados Disponíveis SEM Necessidade de API

### ✅ Dados Públicos Imediatos

Estes dados estão disponíveis **AGORA** sem necessidade de chaves de API:

#### 1. **Portal da Transparência** (Público)
- Servidores públicos federais
- Contratos públicos
- Licitações
- Diárias de viagens
- Despesas públicas

**Como usar:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/servidores?pagina=1"
```

#### 2. **TSE - Dados Eleitorais** (Público)
- Candidatos por eleição
- Doações de campanha
- Bens declarados
- Resultados eleitorais

**Como usar:**
```bash
curl "https://dadosabertos.tse.jus.br/dataset/candidatos-2024/download"
```

#### 3. **Compras.gov.br** (Público)
- Contratos públicos
- Fornecedores registrados
- Licitações

**Como usar:**
```bash
curl "https://www.compras.gov.br/api/contratos?pagina=1&limite=100"
```

#### 4. **CEIS - Empresas Sancionadas** (Público)
- Empresas impedidas de contratar
- Motivos de sanção
- Períodos de vigência

**Como usar:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/ceis?pagina=1"
```

#### 5. **CNEP - Pessoas Sancionadas** (Público)
- Pessoas com sanções administrativas
- Detalhes de punições
- Órgãos responsáveis

**Como usar:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/cnep?pagina=1"
```

---

## 🔐 APIs que Requerem Chaves (Opcionais)

### Portal da Transparência - Dados Sensíveis

**Requer:** Token de API

**Como Obter:**
1. Acesse: https://www.portaldatransparencia.gov.br/api-de-dados
2. Clique em "Solicitar Token"
3. Preencha formulário
4. Tempo de aprovação: 1-3 dias úteis

**Variável de Ambiente:**
```bash
TRANSPARENCY_API_TOKEN=seu_token_aqui
```

**Dados Adicionais:**
- Informações detalhadas de servidores
- Detalhes completos de contratos
- Dados de viagens de autoridades

---

### Google Maps API (Opcional)

**Para:** Visualização de localidades e endereços

**Como Obter:**
1. Acesse: https://console.cloud.google.com
2. Ative "Google Maps JavaScript API"
3. Crie uma chave de API

**Variável de Ambiente:**
```bash
GOOGLE_MAPS_API_KEY=sua_chave_aqui
```

**Status:** ✅ Já integrado (usa proxy Manus)

---

### OpenAI / Claude (Opcional)

**Para:** Análise automática de padrões suspeitos

**Como Obter:**
- OpenAI: https://platform.openai.com/api-keys
- Anthropic: https://console.anthropic.com

**Variável de Ambiente:**
```bash
OPENAI_API_KEY=sua_chave_aqui
```

---

## 📋 Fluxo de Uso Recomendado

### Fase 1: Teste com Dados de Demo (Hoje)
```
1. Acesse /admin
2. Clique "Carregar Dados Demo"
3. Explore /dashboard, /graph, /search
4. Teste geração de relatórios em PDF
```

### Fase 2: Sincronize Dados Públicos (Sem API)
```
1. No admin, clique "Sincronizar Agora"
2. Sistema coleta dados de:
   - Portal da Transparência (público)
   - TSE (público)
   - Compras.gov.br (público)
   - CEIS/CNEP (público)
3. Dados são armazenados no MySQL
4. Grafos são construídos no Neo4j
```

### Fase 3: Configure APIs Opcionais (Próxima Semana)
```
1. Solicite token do Portal da Transparência
2. Configure GOOGLE_MAPS_API_KEY (se necessário)
3. Configure OPENAI_API_KEY (para IA)
4. Reinicie o sistema
5. Dados adicionais serão coletados automaticamente
```

---

## 🎯 Funcionalidades Principais

### 1. Dashboard Admin (`/admin`)
- Status de sincronização em tempo real
- Estatísticas de cache
- Botões para sincronizar, limpar cache, agendar
- Botão para carregar dados de demo
- Histórico de sincronizações

### 2. Dashboard Principal (`/dashboard`)
- Barra de busca por CPF/CNPJ/nome
- Estatísticas gerais
- Links para grafos e busca

### 3. Visualização de Grafos (`/graph`)
- Grafo interativo com Cytoscape.js
- Nós: pessoas (azul), empresas (verde), contratos (laranja)
- Arestas: relacionamentos com tipos
- Zoom, pan, filtros
- Painel lateral com detalhes

### 4. Busca de Entidades (`/search`)
- Resultados detalhados
- Alertas associados
- Conexões de grafo
- Botão para exportar relatório em PDF

### 5. Geração de Relatórios
- PDF com informações completas
- Estatísticas calculadas
- Alertas destacados
- Conexões visualizadas
- Timestamp de geração

---

## 🔧 Configuração de Ambiente

### Desenvolvimento (Sem APIs Externas)
```bash
# .env.local
TRANSPARENCY_API_TOKEN=demo_mode
TSE_DATA_MODE=local_cache
COMPRAS_API_MODE=local_cache
NODE_ENV=development
```

### Produção (Com APIs)
```bash
# .env.production
TRANSPARENCY_API_TOKEN=seu_token_aqui
GOOGLE_MAPS_API_KEY=sua_chave_aqui
OPENAI_API_KEY=sua_chave_aqui
NODE_ENV=production
```

---

## 📊 Estrutura de Dados

### Tabelas MySQL

```
┌─────────────────────────────────────────┐
│         public_servants                 │
├─────────────────────────────────────────┤
│ id, cpf, name, organ, position,         │
│ salary, admissionDate, dataSource       │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         companies                       │
├─────────────────────────────────────────┤
│ id, cnpj, legalName, tradeName,         │
│ sector, foundedDate, dataSource         │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         contracts                       │
├─────────────────────────────────────────┤
│ id, contractNumber, organ,              │
│ contractValue, contractDate, status     │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         alerts                          │
├─────────────────────────────────────────┤
│ id, alertType, description, severity,   │
│ entityCpfCnpj, relatedEntities, created │
└─────────────────────────────────────────┘
```

### Nós Neo4j

```
Person(cpf, name, position, organ)
Company(cnpj, legalName, sector)
Contract(id, number, value, date)
```

### Relacionamentos Neo4j

```
Person -[WORKS_AT]-> Organ
Person -[RELATED_TO]-> Company
Company -[SIGNED]-> Contract
Person -[INVOLVED_IN]-> Contract
```

---

## 🚨 Padrões Detectados Automaticamente

O sistema detecta automaticamente:

1. **Duplo Vínculo Público-Privado**
   - Servidor público trabalhando em empresa que recebe contratos

2. **Funcionários Fantasmas**
   - Pessoas registradas mas sem atividades

3. **Contratos com Parentes**
   - Empresas de familiares recebendo contratos

4. **Fluxo Circular de Recursos**
   - Dinheiro público retornando via doações

5. **Sanções Não Declaradas**
   - Pessoas/empresas em CEIS/CNEP recebendo contratos

---

## 📞 Suporte

### Documentação Completa
- `API_KEYS_GUIDE.md` - Detalhes de todas as APIs
- `ARCHITECTURE.md` - Arquitetura do sistema
- `DOCUMENTATION.md` - Documentação técnica

### Próximos Passos
1. ✅ Testar com dados de demo
2. 🔄 Sincronizar dados públicos
3. 🔄 Solicitar APIs opcionais
4. 🔄 Integrar IA para análise

---

**Versão:** 1.0  
**Data:** Março 2026  
**Status:** Pronto para Uso
