/**
 * Schema de Notificações
 * Tabelas para gerenciar notificações e preferências de alertas
 */

import { int, varchar, text, timestamp, boolean, mysqlTable, index } from "drizzle-orm/mysql-core";

/**
 * Notificações - Notificações de alertas para usuários
 */
export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id"),
    alertId: int("alert_id"),
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message"),
    type: varchar("type", { length: 50 }).notNull(), // 'high_risk_connection', 'suspicious_pattern', 'new_alert'
    severity: varchar("severity", { length: 20 }).notNull(), // 'critical', 'high', 'medium', 'low'
    read: boolean("read").default(false),
    actionUrl: varchar("action_url", { length: 500 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    expiresAt: timestamp("expires_at"),
  },
  (table) => ({
    userIdIdx: index("idx_user_id").on(table.userId),
    alertIdIdx: index("idx_alert_id").on(table.alertId),
    typeIdx: index("idx_type").on(table.type),
    severityIdx: index("idx_severity").on(table.severity),
    readIdx: index("idx_read").on(table.read),
    createdAtIdx: index("idx_created_at").on(table.createdAt),
  })
);

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Preferências de Notificação - Configurações de alertas por usuário
 */
export const notificationPreferences = mysqlTable(
  "notification_preferences",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull(),
    enableHighRiskAlerts: boolean("enable_high_risk_alerts").default(true),
    enableMediumRiskAlerts: boolean("enable_medium_risk_alerts").default(true),
    enableLowRiskAlerts: boolean("enable_low_risk_alerts").default(false),
    enableRealTimeNotifications: boolean("enable_real_time_notifications").default(true),
    enableEmailNotifications: boolean("enable_email_notifications").default(false),
    emailAddress: varchar("email_address", { length: 255 }),
    notificationFrequency: varchar("notification_frequency", { length: 50 }).default("immediate"), // 'immediate', 'daily', 'weekly'
    watchedEntities: text("watched_entities"), // JSON array de CPF/CNPJ
    alertKeywords: text("alert_keywords"), // JSON array de palavras-chave
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("idx_user_id").on(table.userId),
  })
);

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = typeof notificationPreferences.$inferInsert;

/**
 * Histórico de Alertas - Log de todos os alertas gerados
 */
export const alertHistory = mysqlTable(
  "alert_history",
  {
    id: int("id").autoincrement().primaryKey(),
    alertId: int("alert_id"),
    entityCpfCnpj: varchar("entity_cpf_cnpj", { length: 14 }),
    alertType: varchar("alert_type", { length: 100 }).notNull(),
    description: text("description"),
    severity: varchar("severity", { length: 20 }).notNull(),
    riskScore: int("risk_score"), // 0-100
    connectedEntities: text("connected_entities"), // JSON array
    evidence: text("evidence"), // JSON com evidências
    status: varchar("status", { length: 50 }).default("open"), // 'open', 'investigating', 'resolved', 'dismissed'
    investigationNotes: text("investigation_notes"),
    resolvedAt: timestamp("resolved_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    alertIdIdx: index("idx_alert_id").on(table.alertId),
    entityIdx: index("idx_entity").on(table.entityCpfCnpj),
    typeIdx: index("idx_type").on(table.alertType),
    severityIdx: index("idx_severity").on(table.severity),
    statusIdx: index("idx_status").on(table.status),
    createdAtIdx: index("idx_created_at").on(table.createdAt),
  })
);

export type AlertHistory = typeof alertHistory.$inferSelect;
export type InsertAlertHistory = typeof alertHistory.$inferInsert;

/**
 * Detecção de Padrões - Registro de padrões suspeitos detectados
 */
export const suspiciousPatterns = mysqlTable(
  "suspicious_patterns",
  {
    id: int("id").autoincrement().primaryKey(),
    patternType: varchar("pattern_type", { length: 100 }).notNull(), // 'dual_employment', 'ghost_employee', 'family_contract', 'circular_flow'
    description: text("description"),
    severity: varchar("severity", { length: 20 }).notNull(),
    riskScore: int("risk_score"), // 0-100
    primaryEntity: varchar("primary_entity", { length: 14 }),
    relatedEntities: text("related_entities"), // JSON array
    evidence: text("evidence"), // JSON com evidências
    detectedAt: timestamp("detected_at").defaultNow().notNull(),
    investigationStatus: varchar("investigation_status", { length: 50 }).default("pending"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    patternTypeIdx: index("idx_pattern_type").on(table.patternType),
    severityIdx: index("idx_severity").on(table.severity),
    primaryEntityIdx: index("idx_primary_entity").on(table.primaryEntity),
    statusIdx: index("idx_status").on(table.investigationStatus),
    detectedAtIdx: index("idx_detected_at").on(table.detectedAt),
  })
);

export type SuspiciousPattern = typeof suspiciousPatterns.$inferSelect;
export type InsertSuspiciousPattern = typeof suspiciousPatterns.$inferInsert;
