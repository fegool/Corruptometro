import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileDown, Loader2 } from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

interface ReportExporterProps {
  entityCpfCnpj: string;
  entityType: "person" | "company" | "candidate";
  entityName: string;
}

export default function ReportExporter({
  entityCpfCnpj,
  entityType,
  entityName,
}: ReportExporterProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch report data
  const reportQuery = trpc.report.generateInvestigationReport.useQuery(
    {
      entityCpfCnpj,
      entityType,
      includeGraphData: true,
      includeDonations: true,
      includeContracts: true,
    },
    { enabled: false }
  );

  const handleExportPDF = async () => {
    setIsGenerating(true);
    try {
      // Fetch report data
      const response = await reportQuery.refetch();
      if (!response.data?.data) {
        alert("Erro ao gerar relatório");
        setIsGenerating(false);
        return;
      }

      const reportData = response.data.data;

      // Create PDF
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 15;
      const contentWidth = pageWidth - 2 * margin;
      let yPosition = margin;

      // Helper function to add text with wrapping
      const addText = (
        text: string,
        fontSize: number = 11,
        isBold: boolean = false,
        color: [number, number, number] = [0, 0, 0]
      ) => {
        pdf.setFontSize(fontSize);
        pdf.setTextColor(color[0], color[1], color[2]);
        pdf.setFont("helvetica", isBold ? "bold" : "normal");

        const lines = pdf.splitTextToSize(text, contentWidth);
        const lineHeight = fontSize * 0.35;
        const textHeight = lines.length * lineHeight;

        if (yPosition + textHeight > pageHeight - margin) {
          pdf.addPage();
          yPosition = margin;
        }

        pdf.text(lines, margin, yPosition);
        yPosition += textHeight + 5;
      };

      // Title
      addText("RELATÓRIO DE INVESTIGAÇÃO", 16, true, [0, 51, 102]);
      addText("Sistema de Análise de Dados Públicos", 10, false, [100, 100, 100]);
      yPosition += 5;

      // Entity Information
      addText("INFORMAÇÕES DA ENTIDADE", 12, true, [0, 51, 102]);
      if (reportData.entity) {
        addText(`Tipo: ${reportData.entity.type}`, 10);
        addText(`Nome: ${reportData.entity.name}`, 10);
        if (reportData.entity.cpf) addText(`CPF: ${reportData.entity.cpf}`, 10);
        if (reportData.entity.cnpj) addText(`CNPJ: ${reportData.entity.cnpj}`, 10);
        if (reportData.entity.position) addText(`Posição: ${reportData.entity.position}`, 10);
        if (reportData.entity.organ) addText(`Órgão: ${reportData.entity.organ}`, 10);
        if (reportData.entity.party) addText(`Partido: ${reportData.entity.party}`, 10);
        if (reportData.entity.sector) addText(`Setor: ${reportData.entity.sector}`, 10);
      }
      yPosition += 5;

      // Statistics
      if (reportData.statistics && Object.keys(reportData.statistics).length > 0) {
        addText("ESTATÍSTICAS", 12, true, [0, 51, 102]);
        Object.entries(reportData.statistics).forEach(([key, value]) => {
          const formattedKey = key
            .replace(/([A-Z])/g, " $1")
            .replace(/^./, (str) => str.toUpperCase());
          const formattedValue =
            typeof value === "number" && value > 1000
              ? `R$ ${(value as number).toLocaleString("pt-BR")}`
              : value;
          addText(`${formattedKey}: ${formattedValue}`, 10);
        });
      }
      yPosition += 5;

      // Alerts
      if (reportData.alerts && reportData.alerts.length > 0) {
        addText("ALERTAS ENCONTRADOS", 12, true, [255, 0, 0]);
        reportData.alerts.forEach((alert: any) => {
          const severityColor =
            alert.severity === "high"
              ? [255, 0, 0]
              : alert.severity === "medium"
                ? [255, 165, 0]
                : [0, 128, 0];
          addText(
            `[${alert.severity.toUpperCase()}] ${alert.type}`,
            10,
            true,
            severityColor as [number, number, number]
          );
          addText(alert.description, 9);
          yPosition += 3;
        });
      }

      // Contracts
      if (reportData.contracts && reportData.contracts.length > 0) {
        yPosition += 5;
        addText("CONTRATOS", 12, true, [0, 51, 102]);
        addText(`Total de contratos: ${reportData.contracts.length}`, 10);
        if (reportData.statistics?.totalContractValue) {
          addText(
            `Valor total: R$ ${Number(reportData.statistics.totalContractValue).toLocaleString("pt-BR")}`,
            10
          );
        }

        // Show first 10 contracts
        reportData.contracts.slice(0, 10).forEach((contract: any) => {
          const contractInfo = `Contrato #${contract.id} - ${contract.type || "N/A"} - R$ ${Number(contract.value || 0).toLocaleString("pt-BR")}`;
          addText(contractInfo, 9);
        });

        if (reportData.contracts.length > 10) {
          addText(`... e mais ${reportData.contracts.length - 10} contratos`, 9);
        }
      }

      // Donations
      if (reportData.donations && reportData.donations.length > 0) {
        yPosition += 5;
        addText("DOAÇÕES", 12, true, [0, 51, 102]);
        addText(`Total de doações: ${reportData.donations.length}`, 10);
        if (reportData.statistics?.totalDonationAmount) {
          addText(
            `Valor total: R$ ${Number(reportData.statistics.totalDonationAmount).toLocaleString("pt-BR")}`,
            10
          );
        }

        reportData.donations.slice(0, 10).forEach((donation: any) => {
          const donationInfo = `${donation.donorName} - R$ ${Number(donation.amount || 0).toLocaleString("pt-BR")}`;
          addText(donationInfo, 9);
        });

        if (reportData.donations.length > 10) {
          addText(`... e mais ${reportData.donations.length - 10} doações`, 9);
        }
      }

      // Graph Summary
      if (reportData.graphData?.nodes && reportData.graphData.nodes.length > 0) {
        yPosition += 5;
        addText("ANÁLISE DE CONEXÕES", 12, true, [0, 51, 102]);
        addText(`Nós identificados: ${reportData.graphData.nodes.length}`, 10);
        addText(`Conexões encontradas: ${reportData.graphData.edges.length}`, 10);
      }

      // Footer
      yPosition = pageHeight - margin - 10;
      pdf.setFontSize(8);
      pdf.setTextColor(150, 150, 150);
      pdf.text(
        `Relatório gerado em ${new Date().toLocaleString("pt-BR")}`,
        margin,
        yPosition
      );
      pdf.text(
        `Investigador de Corrupção Política - Sistema de Análise de Dados Públicos`,
        margin,
        yPosition + 5
      );

      // Save PDF
      const filename = `relatorio_${entityType}_${entityCpfCnpj}_${new Date().getTime()}.pdf`;
      pdf.save(filename);

      alert("Relatório gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      alert("Erro ao gerar relatório em PDF");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-white">Exportar Relatório</CardTitle>
        <CardDescription>Gerar relatório em PDF com todas as evidências</CardDescription>
      </CardHeader>
      <CardContent>
        <Button
          onClick={handleExportPDF}
          disabled={isGenerating}
          className="w-full bg-green-600 hover:bg-green-700 text-white"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Gerando relatório...
            </>
          ) : (
            <>
              <FileDown className="w-4 h-4 mr-2" />
              Exportar para PDF
            </>
          )}
        </Button>
        <p className="text-xs text-slate-400 mt-3">
          O relatório incluirá todas as informações, contratos, doações e alertas associados a esta
          entidade.
        </p>
      </CardContent>
    </Card>
  );
}
