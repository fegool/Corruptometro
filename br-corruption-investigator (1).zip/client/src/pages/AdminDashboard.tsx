import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Activity,
  Database,
  Zap,
  RefreshCw,
  Settings,
  AlertCircle,
  CheckCircle,
  Clock,
  BarChart3,
} from "lucide-react";

export default function AdminDashboard() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(30); // segundos

  // Queries
  const syncStatusQuery = trpc.admin.getSyncStatus.useQuery(undefined, {
    refetchInterval: autoRefresh ? refreshInterval * 1000 : false,
  });

  const cacheStatsQuery = trpc.admin.getCacheStats.useQuery(undefined, {
    refetchInterval: autoRefresh ? refreshInterval * 1000 : false,
  });

  // Mutations
  const startSyncMutation = trpc.admin.startSync.useMutation({
    onSuccess: () => {
      syncStatusQuery.refetch();
    },
  });

  const clearCacheMutation = trpc.admin.clearCache.useMutation({
    onSuccess: () => {
      cacheStatsQuery.refetch();
    },
  });

  const scheduleSyncMutation = trpc.admin.scheduleSyncInterval.useMutation();

  const loadDemoMutation = trpc.admin.loadDemoData.useMutation({
    onSuccess: () => {
      syncStatusQuery.refetch();
      cacheStatsQuery.refetch();
    },
  });

  const syncStatus = syncStatusQuery.data;
  const cacheStats = cacheStatsQuery.data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Painel de Administração</h1>
          <p className="text-slate-400">Gerenciar sincronização de dados, cache e conexões</p>
        </div>

        {/* Status Geral */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Sincronização */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white flex items-center gap-2">
                <RefreshCw className="w-5 h-5" />
                Sincronização
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">Status</p>
                <div className="flex items-center gap-2">
                  {syncStatus?.isRunning ? (
                    <>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                      <span className="text-yellow-400">Em andamento</span>
                    </>
                  ) : (
                    <>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-green-400">Inativo</span>
                    </>
                  )}
                </div>
              </div>

              {syncStatus?.lastSync && (
                <div>
                  <p className="text-sm text-slate-400 mb-1">Última sincronização</p>
                  <p className="text-white text-sm">
                    {new Date(syncStatus.lastSync).toLocaleString("pt-BR")}
                  </p>
                </div>
              )}

              <Button
                onClick={() => startSyncMutation.mutate()}
                disabled={startSyncMutation.isPending || syncStatus?.isRunning}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                {startSyncMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Sincronizando...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Sincronizar Agora
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Cache */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white flex items-center gap-2">
                <Database className="w-5 h-5" />
                Cache
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">Entradas em Cache</p>
                <p className="text-2xl font-bold text-white">{cacheStats?.size || 0}</p>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-1">Uso de Memória</p>
                <p className="text-white text-sm">
                  {cacheStats ? `${(cacheStats.memoryUsage / 1024).toFixed(2)} KB` : "N/A"}
                </p>
              </div>

              <Button
                onClick={() => clearCacheMutation.mutate()}
                disabled={clearCacheMutation.isPending}
                className="w-full bg-red-600 hover:bg-red-700 text-white"
              >
                {clearCacheMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Limpando...
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Limpar Cache
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Configurações */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Configurações
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoRefresh}
                    onChange={(e) => setAutoRefresh(e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-white text-sm">Auto-atualizar</span>
                </label>
              </div>

              {autoRefresh && (
                <div>
                  <label className="text-sm text-slate-400 mb-1 block">
                    Intervalo (segundos)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="300"
                    value={refreshInterval}
                    onChange={(e) => setRefreshInterval(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white text-sm"
                  />
                </div>
              )}

              <Button
                onClick={() => scheduleSyncMutation.mutate({ intervalMinutes: 60 })}
                disabled={scheduleSyncMutation.isPending}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white mb-2"
              >
                {scheduleSyncMutation.isPending ? (
                  <>
                    <Clock className="w-4 h-4 mr-2 animate-spin" />
                    Agendando...
                  </>
                ) : (
                  <>
                    <Clock className="w-4 h-4 mr-2" />
                    Agendar (1h)
                  </>
                )}
              </Button>

              <Button
                onClick={() => loadDemoMutation.mutate()}
                disabled={loadDemoMutation.isPending}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                {loadDemoMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Carregando...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Carregar Dados Demo
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Resultados de Sincronização */}
        {syncStatus?.results && syncStatus.results.length > 0 && (
          <Card className="bg-slate-800 border-slate-700 mb-8">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Resultados de Sincronização
              </CardTitle>
              <CardDescription>Últimos resultados das fontes de dados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {syncStatus.results.map((result, idx) => (
                  <div key={idx} className="p-4 bg-slate-700 rounded-lg border border-slate-600">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-white font-semibold flex items-center gap-2">
                          {result.success ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-red-500" />
                          )}
                          {result.source}
                        </h3>
                        <p className="text-sm text-slate-400 mt-1">
                          {new Date(result.timestamp).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <span className="text-sm font-mono text-slate-300">
                        {result.duration}ms
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-slate-400">Registros Processados</p>
                        <p className="text-lg font-bold text-white">{result.count}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400">Erros</p>
                        <p className={`text-lg font-bold ${result.errors.length > 0 ? "text-red-400" : "text-green-400"}`}>
                          {result.errors.length}
                        </p>
                      </div>
                    </div>

                    {result.errors.length > 0 && (
                      <div className="mt-3 p-2 bg-red-900/30 border border-red-700 rounded text-sm text-red-200">
                        <p className="font-semibold mb-1">Erros:</p>
                        <ul className="list-disc list-inside space-y-1">
                          {result.errors.map((error, i) => (
                            <li key={i} className="text-xs">
                              {error}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Cache Keys */}
        {cacheStats?.keys && cacheStats.keys.length > 0 && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Chaves em Cache</CardTitle>
              <CardDescription>Dados armazenados em memória</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {cacheStats.keys.map((key, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-700 rounded border border-slate-600 text-sm text-slate-300 font-mono break-all"
                  >
                    {key}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
