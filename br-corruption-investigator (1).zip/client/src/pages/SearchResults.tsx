import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Users, Building2, FileText, TrendingUp } from "lucide-react";
import ReportExporter from "@/components/ReportExporter";

interface SearchParams {
  query: string;
  type: "cpf" | "cnpj" | "all";
}

export default function SearchResults() {
  const [, setLocation] = useLocation();
  const [searchParams, setSearchParams] = useState<SearchParams>({ query: "", type: "all" });
  const [selectedEntity, setSelectedEntity] = useState<any>(null);

  // Get query from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const query = params.get("q") || "";
    const type = (params.get("type") as any) || "all";
    setSearchParams({ query, type });
  }, []);

  // Search query
  const searchQuery = trpc.investigation.search.useQuery(
    { query: searchParams.query, type: searchParams.type },
    { enabled: !!searchParams.query }
  );

  // Get statistics
  const statsQuery = trpc.investigation.getStatistics.useQuery();

  // Get entity details
  const entityDetailsQuery = trpc.investigation.getEntityGraph.useQuery(
    { entityCpfCnpj: selectedEntity },
    { enabled: !!selectedEntity }
  );

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const query = formData.get("query") as string;
    const type = formData.get("type") as string;
    setLocation(`/search?q=${encodeURIComponent(query)}&type=${type}`);
    setSearchParams({ query, type: type as any });
  };

  const results = searchQuery.data;
  const stats = statsQuery.data;

  return (
    <div className="min-h-screen bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Resultados da Busca</h1>
          <p className="text-slate-400">
            Explore os dados públicos sobre políticos, empresas e contratos
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mb-8 p-6 bg-slate-800 border border-slate-700 rounded-lg">
          <div className="flex gap-4">
            <input
              type="text"
              name="query"
              placeholder="Digite CPF, CNPJ ou nome..."
              defaultValue={searchParams.query}
              className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 text-white placeholder:text-slate-400 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <select
              name="type"
              defaultValue={searchParams.type}
              className="px-4 py-2 bg-slate-700 border border-slate-600 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos</option>
              <option value="cpf">CPF</option>
              <option value="cnpj">CNPJ</option>
            </select>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-colors"
            >
              Buscar
            </button>
          </div>
        </form>

        {/* Statistics */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            <div className="p-4 bg-slate-800 border border-slate-700 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Servidores</p>
                  <p className="text-2xl font-bold text-white">{stats.totalServants}</p>
                </div>
                <Users className="w-8 h-8 text-blue-500 opacity-50" />
              </div>
            </div>
            <div className="p-4 bg-slate-800 border border-slate-700 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Empresas</p>
                  <p className="text-2xl font-bold text-white">{stats.totalCompanies}</p>
                </div>
                <Building2 className="w-8 h-8 text-green-500 opacity-50" />
              </div>
            </div>
            <div className="p-4 bg-slate-800 border border-slate-700 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Contratos</p>
                  <p className="text-2xl font-bold text-white">{stats.totalContracts}</p>
                </div>
                <FileText className="w-8 h-8 text-amber-500 opacity-50" />
              </div>
            </div>
            <div className="p-4 bg-slate-800 border border-slate-700 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Candidatos</p>
                  <p className="text-2xl font-bold text-white">{stats.totalCandidates}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-500 opacity-50" />
              </div>
            </div>
            <div className="p-4 bg-red-900/30 border border-red-700 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-red-300">Alertas</p>
                  <p className="text-2xl font-bold text-red-400">{stats.totalAlerts}</p>
                </div>
                <AlertCircle className="w-8 h-8 text-red-500 opacity-50" />
              </div>
            </div>
          </div>
        )}

        {/* Results Grid */}
        {searchParams.query && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Results List */}
            <div className="lg:col-span-2 space-y-4">
              {searchQuery.isLoading && (
                <div className="text-center py-8">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                  <p className="text-slate-300 mt-2">Buscando...</p>
                </div>
              )}

              {/* Servidores */}
              {results?.servants && results.servants.length > 0 && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white">Servidores Públicos</CardTitle>
                    <CardDescription>{results.servants.length} resultado(s)</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {results.servants.map((servant: any) => (
                      <div
                        key={servant.cpf}
                        className="p-3 bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-600 transition-colors"
                        onClick={() => setSelectedEntity(servant.cpf)}
                      >
                        <p className="font-semibold text-white">{servant.name}</p>
                        <p className="text-sm text-slate-400">CPF: {servant.cpf}</p>
                        <p className="text-sm text-slate-400">{servant.position} - {servant.organ}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Empresas */}
              {results?.companies && results.companies.length > 0 && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white">Empresas</CardTitle>
                    <CardDescription>{results.companies.length} resultado(s)</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {results.companies.map((company: any) => (
                      <div
                        key={company.cnpj}
                        className="p-3 bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-600 transition-colors"
                        onClick={() => setSelectedEntity(company.cnpj)}
                      >
                        <p className="font-semibold text-white">{company.legalName}</p>
                        <p className="text-sm text-slate-400">CNPJ: {company.cnpj}</p>
                        <p className="text-sm text-slate-400">Setor: {company.sector || "N/A"}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Candidatos */}
              {results?.candidates && results.candidates.length > 0 && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white">Candidatos</CardTitle>
                    <CardDescription>{results.candidates.length} resultado(s)</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {results.candidates.map((candidate: any) => (
                      <div
                        key={candidate.cpf}
                        className="p-3 bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-600 transition-colors"
                        onClick={() => setSelectedEntity(candidate.cpf)}
                      >
                        <p className="font-semibold text-white">{candidate.name}</p>
                        <p className="text-sm text-slate-400">CPF: {candidate.cpf}</p>
                        <p className="text-sm text-slate-400">{candidate.position} - {candidate.party}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {!searchQuery.isLoading && !results?.servants?.length && !results?.companies?.length && !results?.candidates?.length && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="py-8 text-center">
                    <p className="text-slate-400">Nenhum resultado encontrado para "{searchParams.query}"</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Details Panel */}
            <div className="lg:col-span-1 space-y-4">
              {selectedEntity && entityDetailsQuery.data ? (
                <>
                  <Card className="bg-slate-800 border-slate-700 sticky top-8">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-sm">Detalhes & Conexões</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Nós no Grafo</p>
                        <p className="text-lg font-bold text-white">{entityDetailsQuery.data.nodes.length}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Conexões</p>
                        <p className="text-lg font-bold text-white">{entityDetailsQuery.data.edges.length}</p>
                      </div>
                      {entityDetailsQuery.data.alerts && entityDetailsQuery.data.alerts.length > 0 && (
                        <div>
                          <p className="text-xs text-slate-400 mb-2">Alertas</p>
                          <div className="space-y-2">
                            {entityDetailsQuery.data.alerts.map((alert: any) => (
                              <div key={alert.id} className="p-2 bg-red-900/30 border border-red-700 rounded text-xs">
                                <p className="text-red-300 font-semibold">{alert.alertType}</p>
                                <p className="text-red-200 text-xs">{alert.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      <Button className="w-full bg-purple-600 hover:bg-purple-700" size="sm">
                        Ver Grafo Completo
                      </Button>
                    </CardContent>
                  </Card>
                  <ReportExporter
                    entityCpfCnpj={selectedEntity}
                    entityType={searchParams.type === "cpf" ? "person" : "company"}
                    entityName={selectedEntity}
                  />
                </>
              ) : (
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="py-8 text-center">
                    <p className="text-sm text-slate-400">Clique em um resultado para ver detalhes</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}

        {!searchParams.query && (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="py-12 text-center">
              <p className="text-slate-400 mb-4">Digite um CPF, CNPJ ou nome para começar a busca</p>
              <p className="text-sm text-slate-500">Explore conexões entre políticos, empresas e contratos públicos</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
