/**
 * Coletor de Dados - CEIS/CNEP/CEPIM
 * Coleta dados de empresas e pessoas com sanções
 */

import axios from "axios";
import { getDb } from "../db";
import { companies, publicServants, alerts } from "../../drizzle/schema";

const CEIS_API_BASE = "https://www.portaldatransparencia.gov.br/api-de-dados";

interface CEISRecord {
  cnpj: string;
  nome: string;
  nomeFantasia?: string;
  dataInicio: string;
  dataFim?: string;
  motivo: string;
  tipoSancao: string;
  orgao: string;
}

interface CNEPRecord {
  cpf: string;
  nome: string;
  dataInicio: string;
  dataFim?: string;
  motivo: string;
  tipoSancao: string;
  orgao: string;
}

/**
 * Buscar registros no CEIS (Cadastro de Empresas Inidôneas)
 */
export async function fetchCEISRecords(
  filters?: {
    cnpj?: string;
    dataInicio?: string;
    dataFim?: string;
  }
): Promise<CEISRecord[]> {
  try {
    const params = new URLSearchParams();

    if (filters?.cnpj) params.append("cnpj", filters.cnpj);
    if (filters?.dataInicio) params.append("dataInicio", filters.dataInicio);
    if (filters?.dataFim) params.append("dataFim", filters.dataFim);

    params.append("pagina", "1");
    params.append("tamanhoPagina", "100");

    const response = await axios.get(`${CEIS_API_BASE}/ceis`, { params });

    return response.data?.data || [];
  } catch (error) {
    console.error("[CEISCollector] Erro ao buscar registros CEIS:", error);
    return [];
  }
}

/**
 * Buscar registros no CNEP (Cadastro Nacional de Empresas Punidas)
 */
export async function fetchCNEPRecords(
  filters?: {
    cpf?: string;
    dataInicio?: string;
    dataFim?: string;
  }
): Promise<CNEPRecord[]> {
  try {
    const params = new URLSearchParams();

    if (filters?.cpf) params.append("cpf", filters.cpf);
    if (filters?.dataInicio) params.append("dataInicio", filters.dataInicio);
    if (filters?.dataFim) params.append("dataFim", filters.dataFim);

    params.append("pagina", "1");
    params.append("tamanhoPagina", "100");

    const response = await axios.get(`${CEIS_API_BASE}/cnep`, { params });

    return response.data?.data || [];
  } catch (error) {
    console.error("[CEISCollector] Erro ao buscar registros CNEP:", error);
    return [];
  }
}

/**
 * Sincronizar registros CEIS com banco de dados
 */
export async function syncCEISRecords(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const db = await getDb();
  if (!db) {
    return { success: false, count: 0, errors: ["Database not available"] };
  }

  const errors: string[] = [];
  let count = 0;

  try {
    console.log("[CEISCollector] Iniciando sincronização de registros CEIS...");

    const ceisData = await fetchCEISRecords();

    for (const record of ceisData) {
      try {
        // Inserir ou atualizar empresa
        await db.insert(companies).values({
          cnpj: record.cnpj,
          legalName: record.nome,
          tradeName: record.nomeFantasia,
          dataSource: "ceis",
        }).onDuplicateKeyUpdate({
          set: {
            legalName: record.nome,
            tradeName: record.nomeFantasia,
          },
        });

        // Criar alerta de sanção
        await db.insert(alerts).values({
          entityCpfCnpj: record.cnpj,
          alertType: `CEIS_${record.tipoSancao}`,
          description: `Empresa consta em CEIS: ${record.motivo}. Período: ${record.dataInicio} a ${record.dataFim || "em vigor"}. Órgão: ${record.orgao}`,
          severity: "high",
        });

        count++;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        errors.push(`Erro ao sincronizar CEIS ${record.cnpj}: ${errorMsg}`);
      }
    }

    console.log(`[CEISCollector] Sincronização CEIS concluída: ${count} registros processados`);
    return { success: true, count, errors };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error("[CEISCollector] Erro durante sincronização CEIS:", errorMsg);
    return { success: false, count, errors: [errorMsg] };
  }
}

/**
 * Sincronizar registros CNEP com banco de dados
 */
export async function syncCNEPRecords(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const db = await getDb();
  if (!db) {
    return { success: false, count: 0, errors: ["Database not available"] };
  }

  const errors: string[] = [];
  let count = 0;

  try {
    console.log("[CEISCollector] Iniciando sincronização de registros CNEP...");

    const cnepData = await fetchCNEPRecords();

    for (const record of cnepData) {
      try {
        // Inserir ou atualizar pessoa
        await db.insert(publicServants).values({
          cpf: record.cpf,
          name: record.nome,
          dataSource: "cnep",
        }).onDuplicateKeyUpdate({
          set: {
            name: record.nome,
          },
        });

        // Criar alerta de sanção
        await db.insert(alerts).values({
          entityCpfCnpj: record.cpf,
          alertType: `CNEP_${record.tipoSancao}`,
          description: `Pessoa consta em CNEP: ${record.motivo}. Período: ${record.dataInicio} a ${record.dataFim || "em vigor"}. Órgão: ${record.orgao}`,
          severity: "high",
        });

        count++;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        errors.push(`Erro ao sincronizar CNEP ${record.cpf}: ${errorMsg}`);
      }
    }

    console.log(`[CEISCollector] Sincronização CNEP concluída: ${count} registros processados`);
    return { success: true, count, errors };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error("[CEISCollector] Erro durante sincronização CNEP:", errorMsg);
    return { success: false, count, errors: [errorMsg] };
  }
}

/**
 * Sincronizar todas as sanções (CEIS + CNEP)
 */
export async function syncAllSanctions(): Promise<{
  success: boolean;
  ceis: { count: number; errors: string[] };
  cnep: { count: number; errors: string[] };
}> {
  console.log("[CEISCollector] Iniciando sincronização de todas as sanções...");

  const ceisResult = await syncCEISRecords();
  const cnepResult = await syncCNEPRecords();

  return {
    success: ceisResult.success && cnepResult.success,
    ceis: { count: ceisResult.count, errors: ceisResult.errors },
    cnep: { count: cnepResult.count, errors: cnepResult.errors },
  };
}
