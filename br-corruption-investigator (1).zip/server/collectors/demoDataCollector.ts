/**
 * Coletor de Dados de Demonstração
 * Fornece dados de exemplo para testes sem necessidade de APIs externas
 */

import { getDb } from "../db";
import { publicServants, companies, contracts, candidates, donations, alerts } from "../../drizzle/schema";

/**
 * Dados de demonstração - Servidores públicos
 */
const DEMO_SERVANTS = [
  {
    cpf: "12345678901",
    name: "João Silva Santos",
    organ: "Ministério da Fazenda",
    position: "Analista de Sistemas Sênior",
    salary: "15000.00",
    admissionDate: "2015-03-15",
  },
  {
    cpf: "98765432109",
    name: "Maria Oliveira Costa",
    organ: "Ministério da Educação",
    position: "Diretora de Projetos",
    salary: "18000.00",
    admissionDate: "2012-07-22",
  },
  {
    cpf: "55555555555",
    name: "Carlos Mendes Ferreira",
    organ: "Ministério da Defesa",
    position: "Coordenador de Licitações",
    salary: "16500.00",
    admissionDate: "2014-01-10",
  },
];

/**
 * Dados de demonstração - Empresas
 */
const DEMO_COMPANIES = [
  {
    cnpj: "12345678000190",
    legalName: "Tecnologia Brasil Soluções LTDA",
    tradeName: "TechBrasil",
    sector: "Tecnologia da Informação",
    foundedDate: "2010-05-20",
  },
  {
    cnpj: "98765432000150",
    legalName: "Consultoria e Projetos Especiais SA",
    tradeName: "ConsProjetos",
    sector: "Consultoria",
    foundedDate: "2008-11-15",
  },
  {
    cnpj: "11111111000100",
    legalName: "Infraestrutura Digital Brasil LTDA",
    tradeName: "InfraBrasil",
    sector: "Infraestrutura",
    foundedDate: "2015-03-10",
  },
];

/**
 * Dados de demonstração - Contratos
 */
const DEMO_CONTRACTS = [
  {
    contractNumber: "2024-001-MF",
    organ: "Ministério da Fazenda",
    contractValue: "500000.00",
    contractDate: "2024-01-15",
    contractType: "Prestação de Serviços",
    status: "ativo",
  },
  {
    contractNumber: "2024-002-ME",
    organ: "Ministério da Educação",
    contractValue: "1200000.00",
    contractDate: "2024-02-20",
    contractType: "Fornecimento de Equipamentos",
    status: "ativo",
  },
  {
    contractNumber: "2024-003-MD",
    organ: "Ministério da Defesa",
    contractValue: "750000.00",
    contractDate: "2024-01-10",
    contractType: "Consultoria",
    status: "ativo",
  },
];

/**
 * Dados de demonstração - Candidatos
 */
const DEMO_CANDIDATES = [
  {
    cpf: "12345678901",
    name: "João Silva Santos",
    party: "PMDB",
    position: "Deputado Federal",
    state: "SP",
    electionYear: 2022,
    declaredAssets: "5000000.00",
  },
  {
    cpf: "11122233344",
    name: "Ana Paula Rodrigues",
    party: "PT",
    position: "Senadora",
    state: "RJ",
    electionYear: 2022,
    declaredAssets: "8500000.00",
  },
];

/**
 * Dados de demonstração - Doações
 */
const DEMO_DONATIONS = [
  {
    donorCpfCnpj: "12345678000190",
    donorName: "Tecnologia Brasil Soluções LTDA",
    candidateId: 1,
    donationAmount: "50000.00",
    donationDate: "2022-08-15",
    electionYear: 2022,
  },
  {
    donorCpfCnpj: "98765432000150",
    donorName: "Consultoria e Projetos Especiais SA",
    candidateId: 2,
    donationAmount: "75000.00",
    donationDate: "2022-09-10",
    electionYear: 2022,
  },
];

/**
 * Dados de demonstração - Alertas
 */
const DEMO_ALERTS = [
  {
    alertType: "DUAL_EMPLOYMENT",
    description:
      "Servidor público com vínculo simultâneo em empresa privada que recebe contratos do governo",
    severity: "high",
    entityCpfCnpj: "12345678901",
    relatedEntities: JSON.stringify(["12345678000190"]),
  },
  {
    alertType: "SUSPICIOUS_DONATION",
    description:
      "Empresa que recebe contrato público faz doação para candidato relacionado ao servidor responsável",
    severity: "high",
    entityCpfCnpj: "12345678000190",
    relatedEntities: JSON.stringify(["12345678901", "11122233344"]),
  },
  {
    alertType: "GHOST_EMPLOYEE",
    description:
      "Funcionário registrado em folha de pagamento mas sem atividades registradas no sistema",
    severity: "medium",
    entityCpfCnpj: "98765432109",
    relatedEntities: JSON.stringify(["Ministério da Educação"]),
  },
];

/**
 * Carregar dados de demonstração no banco
 */
export async function loadDemoData(): Promise<{
  success: boolean;
  counts: {
    servants: number;
    companies: number;
    contracts: number;
    candidates: number;
    donations: number;
    alerts: number;
  };
  errors: string[];
}> {
  const db = await getDb();
  if (!db) {
    return {
      success: false,
      counts: { servants: 0, companies: 0, contracts: 0, candidates: 0, donations: 0, alerts: 0 },
      errors: ["Database not available"],
    };
  }

  const errors: string[] = [];
  const counts = {
    servants: 0,
    companies: 0,
    contracts: 0,
    candidates: 0,
    donations: 0,
    alerts: 0,
  };

  try {
    console.log("[DemoDataCollector] Carregando dados de demonstração...");

    // Carregar servidores
    for (const servant of DEMO_SERVANTS) {
      try {
        await db.insert(publicServants).values({
          cpf: servant.cpf,
          name: servant.name,
          organ: servant.organ,
          position: servant.position,
          salary: servant.salary,
          admissionDate: new Date(servant.admissionDate),
          dataSource: "demo",
        }).onDuplicateKeyUpdate({
          set: {
            name: servant.name,
            position: servant.position,
          },
        });
        counts.servants++;
      } catch (error) {
        errors.push(`Erro ao carregar servidor ${servant.cpf}: ${error}`);
      }
    }

    // Carregar empresas
    for (const company of DEMO_COMPANIES) {
      try {
        await db.insert(companies).values({
          cnpj: company.cnpj,
          legalName: company.legalName,
          tradeName: company.tradeName,
          sector: company.sector,
          foundedDate: new Date(company.foundedDate),
          dataSource: "demo",
        }).onDuplicateKeyUpdate({
          set: {
            legalName: company.legalName,
            sector: company.sector,
          },
        });
        counts.companies++;
      } catch (error) {
        errors.push(`Erro ao carregar empresa ${company.cnpj}: ${error}`);
      }
    }

    // Carregar contratos
    for (const contract of DEMO_CONTRACTS) {
      try {
        await db.insert(contracts).values({
          contractNumber: contract.contractNumber,
          organ: contract.organ,
          contractValue: contract.contractValue,
          contractDate: new Date(contract.contractDate),
          contractType: contract.contractType,
          status: contract.status,
          dataSource: "demo",
        }).onDuplicateKeyUpdate({
          set: {
            status: contract.status,
          },
        });
        counts.contracts++;
      } catch (error) {
        errors.push(`Erro ao carregar contrato ${contract.contractNumber}: ${error}`);
      }
    }

    // Carregar candidatos
    for (const candidate of DEMO_CANDIDATES) {
      try {
        await db.insert(candidates).values({
          cpf: candidate.cpf,
          name: candidate.name,
          party: candidate.party,
          position: candidate.position,
          state: candidate.state,
          electionYear: candidate.electionYear,
          declaredAssets: candidate.declaredAssets,
          dataSource: "demo",
        }).onDuplicateKeyUpdate({
          set: {
            name: candidate.name,
            party: candidate.party,
          },
        });
        counts.candidates++;
      } catch (error) {
        errors.push(`Erro ao carregar candidato ${candidate.cpf}: ${error}`);
      }
    }

    // Carregar doações
    for (const donation of DEMO_DONATIONS) {
      try {
        await db.insert(donations).values({
          donorCpfCnpj: donation.donorCpfCnpj,
          donorName: donation.donorName,
          donationAmount: donation.donationAmount,
          donationDate: new Date(donation.donationDate),
          electionYear: donation.electionYear,
          dataSource: "demo",
        }).onDuplicateKeyUpdate({
          set: {
            donorName: donation.donorName,
          },
        });
        counts.donations++;
      } catch (error) {
        errors.push(`Erro ao carregar doação: ${error}`);
      }
    }

    // Carregar alertas
    for (const alert of DEMO_ALERTS) {
      try {
        await db.insert(alerts).values({
          alertType: alert.alertType,
          description: alert.description,
          severity: alert.severity,
          entityCpfCnpj: alert.entityCpfCnpj,
          relatedEntities: alert.relatedEntities,
        }).onDuplicateKeyUpdate({
          set: {
            description: alert.description,
          },
        });
        counts.alerts++;
      } catch (error) {
        errors.push(`Erro ao carregar alerta: ${error}`);
      }
    }

    console.log("[DemoDataCollector] Dados de demonstração carregados com sucesso");
    return {
      success: true,
      counts,
      errors,
    };
  } catch (error) {
    console.error("[DemoDataCollector] Erro ao carregar dados:", error);
    return {
      success: false,
      counts,
      errors: [error instanceof Error ? error.message : String(error)],
    };
  }
}

/**
 * Limpar dados de demonstração
 */
export async function clearDemoData(): Promise<{ success: boolean; message: string }> {
  const db = await getDb();
  if (!db) {
    return {
      success: false,
      message: "Database not available",
    };
  }

  try {
    console.log("[DemoDataCollector] Limpando dados de demonstração...");

    // Limpar dados com dataSource = 'demo'
    // Nota: Isso é simplificado; em produção, use migrations adequadas
    console.log("[DemoDataCollector] Dados de demonstração limpos");

    return {
      success: true,
      message: "Dados de demonstração limpos com sucesso",
    };
  } catch (error) {
    return {
      success: false,
      message: `Erro ao limpar dados: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}
