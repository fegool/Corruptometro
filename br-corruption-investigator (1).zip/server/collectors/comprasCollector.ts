/**
 * Coletor de Dados - Compras.gov.br
 * Coleta dados de contratos, licitações e fornecedores
 */

import axios from "axios";
import { getDb } from "../db";
import { companies, contracts } from "../../drizzle/schema";

const COMPRAS_API_BASE = "https://www.compras.gov.br/api";

interface ComprasContract {
  id: string;
  numero: string;
  descricao: string;
  valor: number;
  dataAssinatura: string;
  fornecedor: {
    cnpj: string;
    nome: string;
    nomeFantasia?: string;
  };
  orgao: {
    nome: string;
    sigla: string;
  };
}

interface ComprasSupplier {
  cnpj: string;
  nome: string;
  nomeFantasia?: string;
  setor?: string;
  dataConstituicao?: string;
}

/**
 * Buscar contratos no Compras.gov.br
 */
export async function fetchComprasContracts(
  filters?: {
    dataInicio?: string;
    dataFim?: string;
    cnpj?: string;
    orgao?: string;
  }
): Promise<ComprasContract[]> {
  try {
    const params = new URLSearchParams();

    if (filters?.dataInicio) params.append("dataInicio", filters.dataInicio);
    if (filters?.dataFim) params.append("dataFim", filters.dataFim);
    if (filters?.cnpj) params.append("cnpj", filters.cnpj);
    if (filters?.orgao) params.append("orgao", filters.orgao);

    params.append("pagina", "1");
    params.append("limite", "100");

    const response = await axios.get(`${COMPRAS_API_BASE}/contratos`, { params });

    return response.data?.data || [];
  } catch (error) {
    console.error("[ComprasCollector] Erro ao buscar contratos:", error);
    return [];
  }
}

/**
 * Buscar fornecedores no Compras.gov.br
 */
export async function fetchComprasSuppliers(
  filters?: {
    cnpj?: string;
    nome?: string;
  }
): Promise<ComprasSupplier[]> {
  try {
    const params = new URLSearchParams();

    if (filters?.cnpj) params.append("cnpj", filters.cnpj);
    if (filters?.nome) params.append("nome", filters.nome);

    params.append("pagina", "1");
    params.append("limite", "100");

    const response = await axios.get(`${COMPRAS_API_BASE}/fornecedores`, { params });

    return response.data?.data || [];
  } catch (error) {
    console.error("[ComprasCollector] Erro ao buscar fornecedores:", error);
    return [];
  }
}

/**
 * Sincronizar contratos do Compras.gov.br com banco de dados
 */
export async function syncComprasContracts(
  filters?: {
    dataInicio?: string;
    dataFim?: string;
  }
): Promise<{ success: boolean; count: number; errors: string[] }> {
  const db = await getDb();
  if (!db) {
    return { success: false, count: 0, errors: ["Database not available"] };
  }

  const errors: string[] = [];
  let count = 0;

  try {
    console.log("[ComprasCollector] Iniciando sincronização de contratos...");

    const contractsData = await fetchComprasContracts(filters);

    for (const contract of contractsData) {
      try {
        // Inserir ou atualizar empresa fornecedora
        if (contract.fornecedor) {
          await db.insert(companies).values({
            cnpj: contract.fornecedor.cnpj,
            legalName: contract.fornecedor.nome,
            tradeName: contract.fornecedor.nomeFantasia,
            dataSource: "compras.gov.br",
          }).onDuplicateKeyUpdate({
            set: {
              legalName: contract.fornecedor.nome,
              tradeName: contract.fornecedor.nomeFantasia,
            },
          });
        }

        // Inserir ou atualizar contrato
        await db.insert(contracts).values({
          contractNumber: contract.numero,
          companyId: contract.fornecedor?.cnpj ? 1 : undefined, // Simplificado
          organ: contract.orgao?.nome,
          contractValue: contract.valor.toString(),
          contractDate: new Date(contract.dataAssinatura),
          contractType: "Compras",
          status: "ativo",
          dataSource: "compras.gov.br",
        }).onDuplicateKeyUpdate({
          set: {
            contractValue: contract.valor.toString(),
            status: "ativo",
          },
        });

        count++;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        errors.push(`Erro ao sincronizar contrato ${contract.numero}: ${errorMsg}`);
      }
    }

    console.log(
      `[ComprasCollector] Sincronização concluída: ${count} contratos inseridos/atualizados`
    );
    return { success: true, count, errors };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error("[ComprasCollector] Erro durante sincronização:", errorMsg);
    return { success: false, count, errors: [errorMsg] };
  }
}

/**
 * Sincronizar fornecedores do Compras.gov.br com banco de dados
 */
export async function syncComprasSuppliers(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const db = await getDb();
  if (!db) {
    return { success: false, count: 0, errors: ["Database not available"] };
  }

  const errors: string[] = [];
  let count = 0;

  try {
    console.log("[ComprasCollector] Iniciando sincronização de fornecedores...");

    const suppliersData = await fetchComprasSuppliers();

    for (const supplier of suppliersData) {
      try {
        await db.insert(companies).values({
          cnpj: supplier.cnpj,
          legalName: supplier.nome,
          tradeName: supplier.nomeFantasia,
          sector: supplier.setor,
          foundedDate: supplier.dataConstituicao ? new Date(supplier.dataConstituicao) : undefined,
          dataSource: "compras.gov.br",
        }).onDuplicateKeyUpdate({
          set: {
            legalName: supplier.nome,
            tradeName: supplier.nomeFantasia,
            sector: supplier.setor,
          },
        });

        count++;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        errors.push(`Erro ao sincronizar fornecedor ${supplier.cnpj}: ${errorMsg}`);
      }
    }

    console.log(
      `[ComprasCollector] Sincronização concluída: ${count} fornecedores inseridos/atualizados`
    );
    return { success: true, count, errors };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error("[ComprasCollector] Erro durante sincronização:", errorMsg);
    return { success: false, count, errors: [errorMsg] };
  }
}
