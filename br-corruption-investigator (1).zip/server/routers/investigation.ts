/**
 * Roteador de Investigação
 * Procedimentos tRPC para busca, análise e visualização de dados
 */

import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  publicServants,
  companies,
  contracts,
  candidates,
  donations,
  alerts,
} from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const investigationRouter = router({
  /**
   * Busca por CPF/CNPJ
   */
  search: publicProcedure
    .input(
      z.object({
        query: z.string().min(1).max(20),
        type: z.enum(["cpf", "cnpj", "all"]).default("all"),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { results: [] };
      }

      const query = input.query.replace(/[^\d]/g, "");
      const results: any = {
        servants: [],
        companies: [],
        candidates: [],
        donations: [],
      };

      try {
        // Buscar servidores
        if (input.type === "cpf" || input.type === "all") {
          results.servants = await db
            .select()
            .from(publicServants)
            .where(eq(publicServants.cpf, query))
            .limit(10);
        }

        // Buscar empresas
        if (input.type === "cnpj" || input.type === "all") {
          results.companies = await db
            .select()
            .from(companies)
            .where(eq(companies.cnpj, query))
            .limit(10);
        }

        // Buscar candidatos
        if (input.type === "cpf" || input.type === "all") {
          results.candidates = await db
            .select()
            .from(candidates)
            .where(eq(candidates.cpf, query))
            .limit(10);
        }

        // Buscar doações
        if (input.type === "cpf" || input.type === "cnpj" || input.type === "all") {
          results.donations = await db
            .select()
            .from(donations)
            .where(eq(donations.donorCpfCnpj, query))
            .limit(10);
        }

        return results;
      } catch (error) {
        console.error("[Investigation] Erro na busca:", error);
        return results;
      }
    }),

  /**
   * Obter detalhes de um servidor público
   */
  getServantDetails: publicProcedure
    .input(z.object({ cpf: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return null;
      }

      try {
        const servant = await db
          .select()
          .from(publicServants)
          .where(eq(publicServants.cpf, input.cpf))
          .limit(1);

        if (servant.length === 0) {
          return null;
        }

        // Buscar contratos relacionados
        const relatedContracts = await db
          .select()
          .from(contracts)
          .where(eq(contracts.organ, servant[0].organ || ""))
          .limit(20);

        // Buscar alertas
        const relatedAlerts = await db
          .select()
          .from(alerts)
          .where(eq(alerts.entityCpfCnpj, input.cpf))
          .limit(10);

        return {
          servant: servant[0],
          contracts: relatedContracts,
          alerts: relatedAlerts,
        };
      } catch (error) {
        console.error("[Investigation] Erro ao obter detalhes:", error);
        return null;
      }
    }),

  /**
   * Obter detalhes de uma empresa
   */
  getCompanyDetails: publicProcedure
    .input(z.object({ cnpj: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return null;
      }

      try {
        const company = await db
          .select()
          .from(companies)
          .where(eq(companies.cnpj, input.cnpj))
          .limit(1);

        if (company.length === 0) {
          return null;
        }

        // Buscar contratos da empresa
        const companyContracts = await db
          .select()
          .from(contracts)
          .where(eq(contracts.companyId, company[0].id))
          .limit(50);

        // Buscar alertas
        const relatedAlerts = await db
          .select()
          .from(alerts)
          .where(eq(alerts.entityCpfCnpj, input.cnpj))
          .limit(10);

        // Calcular estatísticas
        const totalContractValue = companyContracts.reduce((sum, c) => {
          const value = c.contractValue ? Number(c.contractValue) : 0;
          return sum + value;
        }, 0);

        return {
          company: company[0],
          contracts: companyContracts,
          alerts: relatedAlerts,
          statistics: {
            totalContracts: companyContracts.length,
            totalContractValue: totalContractValue,
            averageContractValue:
              companyContracts.length > 0
                ? totalContractValue / companyContracts.length
                : 0,
          },
        };
      } catch (error) {
        console.error("[Investigation] Erro ao obter detalhes da empresa:", error);
        return null;
      }
    }),

  /**
   * Listar alertas com filtros
   */
  listAlerts: publicProcedure
    .input(
      z.object({
        alertType: z.string().optional(),
        severity: z.enum(["low", "medium", "high"]).optional(),
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { alerts: [], total: 0 };
      }

      try {
        const conditions: any[] = [];

        if (input.alertType) {
          conditions.push(eq(alerts.alertType, input.alertType));
        }

        if (input.severity) {
          conditions.push(eq(alerts.severity, input.severity));
        }

        const allAlerts =
          conditions.length > 0
            ? await db.select().from(alerts).where(and(...conditions))
            : await db.select().from(alerts);

        const paginatedAlerts = allAlerts.slice(input.offset, input.offset + input.limit);

        return {
          alerts: paginatedAlerts,
          total: allAlerts.length,
        };
      } catch (error) {
        console.error("[Investigation] Erro ao listar alertas:", error);
        return { alerts: [], total: 0 };
      }
    }),

  /**
   * Obter estatísticas gerais
   */
  getStatistics: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) {
      return {
        totalServants: 0,
        totalCompanies: 0,
        totalContracts: 0,
        totalCandidates: 0,
        totalAlerts: 0,
      };
    }

    try {
      const servants = await db.select().from(publicServants);
      const companies_ = await db.select().from(companies);
      const contracts_ = await db.select().from(contracts);
      const candidates_ = await db.select().from(candidates);
      const alerts_ = await db.select().from(alerts);

      return {
        totalServants: servants.length,
        totalCompanies: companies_.length,
        totalContracts: contracts_.length,
        totalCandidates: candidates_.length,
        totalAlerts: alerts_.length,
      };
    } catch (error) {
      console.error("[Investigation] Erro ao obter estatísticas:", error);
      return {
        totalServants: 0,
        totalCompanies: 0,
        totalContracts: 0,
        totalCandidates: 0,
        totalAlerts: 0,
      };
    }
  }),

  /**
   * Obter alertas recentes
   */
  getRecentAlerts: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const recentAlerts = await db
          .select()
          .from(alerts)
          .limit(input.limit);

        return recentAlerts;
      } catch (error) {
        console.error("[Investigation] Erro ao obter alertas recentes:", error);
        return [];
      }
    }),

  /**
   * Obter contratos de um órgão
   */
  getOrganContracts: publicProcedure
    .input(z.object({ organ: z.string(), limit: z.number().default(50) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const organContracts = await db
          .select()
          .from(contracts)
          .where(eq(contracts.organ, input.organ))
          .limit(input.limit);

        return organContracts;
      } catch (error) {
        console.error("[Investigation] Erro ao obter contratos do órgão:", error);
        return [];
      }
    }),

  /**
   * Obter doações para um candidato
   */
  getCandidateDonations: publicProcedure
    .input(z.object({ candidateId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const candidateDonations = await db
          .select()
          .from(donations)
          .where(eq(donations.candidateId, input.candidateId));

        return candidateDonations;
      } catch (error) {
        console.error("[Investigation] Erro ao obter doações:", error);
        return [];
      }
    }),

  /**
   * Obter grafo de conexões para uma entidade
   */
  getEntityGraph: publicProcedure
    .input(
      z.object({
        entityCpfCnpj: z.string(),
        depth: z.number().min(1).max(3).default(2),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { nodes: [], edges: [], alerts: [] };
      }

      try {
        const nodes: any[] = [];
        const edges: any[] = [];
        const visited = new Set<string>();

        // Função auxiliar para adicionar nó
        const addNode = (id: string, label: string, type: "person" | "company" | "contract", data: any) => {
          if (!visited.has(id)) {
            visited.add(id);
            nodes.push({ id, label, type, data });
          }
        };

        // Função auxiliar para adicionar aresta
        const addEdge = (source: string, target: string, label: string, type: string) => {
          const edgeId = `${source}-${target}`;
          if (!edges.find((e) => e.id === edgeId)) {
            edges.push({ id: edgeId, source, target, label, type });
          }
        };

        // Buscar servidor público
        const servants = await db
          .select()
          .from(publicServants)
          .where(eq(publicServants.cpf, input.entityCpfCnpj))
          .limit(1);

        if (servants.length > 0) {
          const servant = servants[0];
          addNode(`person-${servant.cpf}`, servant.name || "Servidor", "person", {
            cpf: servant.cpf,
            position: servant.position,
            organ: servant.organ,
          });

          // Buscar contratos do órgão
          const organContracts = await db
            .select()
            .from(contracts)
            .where(eq(contracts.organ, servant.organ || ""))
            .limit(10);

          for (const contract of organContracts) {
            addNode(
              `contract-${contract.id}`,
              `Contrato #${contract.id}`,
              "contract",
              {
                value: contract.contractValue,
                date: contract.contractDate,
              }
            );
            addEdge(
              `person-${servant.cpf}`,
              `contract-${contract.id}`,
              "Relacionado",
              "related_to"
            );

            // Buscar empresa do contrato
            if (contract.companyId) {
              const company = await db
                .select()
                .from(companies)
                .where(eq(companies.id, contract.companyId))
                .limit(1);

              if (company.length > 0) {
                addNode(
                  `company-${company[0].cnpj}`,
                  company[0].legalName || company[0].tradeName || "Empresa",
                  "company",
                  {
                    cnpj: company[0].cnpj,
                    sector: company[0].sector,
                  }
                );
                addEdge(
                  `company-${company[0].cnpj}`,
                  `contract-${contract.id}`,
                  "Assinou",
                  "signed"
                );
              }
            }
          }
        }

        // Buscar empresa
        const companies_ = await db
          .select()
          .from(companies)
          .where(eq(companies.cnpj, input.entityCpfCnpj))
          .limit(1);

        if (companies_.length > 0) {
          const company = companies_[0];
          addNode(`company-${company.cnpj}`, company.legalName || company.tradeName || "Empresa", "company", {
            cnpj: company.cnpj,
            sector: company.sector,
          });

          // Buscar contratos da empresa
          const companyContracts = await db
            .select()
            .from(contracts)
            .where(eq(contracts.companyId, company.id))
            .limit(15);

          for (const contract of companyContracts) {
            addNode(
              `contract-${contract.id}`,
              `Contrato #${contract.id}`,
              "contract",
              {
                value: contract.contractValue,
                date: contract.contractDate,
              }
            );
            addEdge(
              `company-${company.cnpj}`,
              `contract-${contract.id}`,
              "Assinou",
              "signed"
            );
          }
        }

        // Buscar alertas relacionados
        const relatedAlerts = await db
          .select()
          .from(alerts)
          .where(eq(alerts.entityCpfCnpj, input.entityCpfCnpj))
          .limit(5);

        return { nodes, edges, alerts: relatedAlerts };
      } catch (error) {
        console.error("[Investigation] Erro ao obter grafo:", error);
        return { nodes: [], edges: [], alerts: [] };
      }
    }),

  /**
   * Marcar alerta como resolvido
   */
  resolveAlert: protectedProcedure
    .input(z.object({ alertId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { success: false };
      }

      try {
        // Aqui você implementaria a lógica de atualização
        // Por enquanto, apenas retorna sucesso
        return { success: true };
      } catch (error) {
        console.error("[Investigation] Erro ao resolver alerta:", error);
        return { success: false };
      }
    }),
});
