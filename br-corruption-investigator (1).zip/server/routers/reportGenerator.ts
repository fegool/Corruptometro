/**
 * Roteador de Geração de Relatórios
 * Procedimentos tRPC para gerar relatórios em PDF
 */

import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  publicServants,
  companies,
  contracts,
  candidates,
  donations,
  alerts,
} from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const reportGeneratorRouter = router({
  /**
   * Gerar dados para relatório de investigação
   */
  generateInvestigationReport: publicProcedure
    .input(
      z.object({
        entityCpfCnpj: z.string(),
        entityType: z.enum(["person", "company", "candidate"]),
        includeGraphData: z.boolean().default(true),
        includeDonations: z.boolean().default(true),
        includeContracts: z.boolean().default(true),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { success: false, data: null };
      }

      try {
        const reportData: any = {
          generatedAt: new Date().toISOString(),
          entity: null,
          contracts: [],
          donations: [],
          alerts: [],
          statistics: {},
          graphData: { nodes: [], edges: [] },
        };

        // Buscar dados da entidade
        if (input.entityType === "person") {
          const servants = await db
            .select()
            .from(publicServants)
            .where(eq(publicServants.cpf, input.entityCpfCnpj))
            .limit(1);

          if (servants.length > 0) {
            const servant = servants[0];
            reportData.entity = {
              type: "Servidor Público",
              name: servant.name,
              cpf: servant.cpf,
              position: servant.position,
              organ: servant.organ,
              salary: servant.salary,
              dataSource: servant.dataSource,
            };

            // Buscar contratos do órgão
            if (input.includeContracts) {
              const organContracts = await db
                .select()
                .from(contracts)
                .where(eq(contracts.organ, servant.organ || ""))
                .limit(50);

              reportData.contracts = organContracts.map((c) => ({
                id: c.id,
                number: c.contractNumber,
                type: c.contractType,
                value: c.contractValue,
                date: c.contractDate,
                organ: c.organ,
                companyId: c.companyId,
              }));

              reportData.statistics.totalContracts = organContracts.length;
              reportData.statistics.totalContractValue = organContracts.reduce(
                (sum, c) => sum + (Number(c.contractValue) || 0),
                0
              );
            }
          }
        } else if (input.entityType === "company") {
          const companies_ = await db
            .select()
            .from(companies)
            .where(eq(companies.cnpj, input.entityCpfCnpj))
            .limit(1);

          if (companies_.length > 0) {
            const company = companies_[0];
            reportData.entity = {
              type: "Empresa",
              name: company.legalName,
              tradeName: company.tradeName,
              cnpj: company.cnpj,
              sector: company.sector,
              foundedDate: company.foundedDate,
              dataSource: company.dataSource,
            };

            // Buscar contratos da empresa
            if (input.includeContracts) {
              const companyContracts = await db
                .select()
                .from(contracts)
                .where(eq(contracts.companyId, company.id))
                .limit(100);

              reportData.contracts = companyContracts.map((c) => ({
                id: c.id,
                number: c.contractNumber,
                type: c.contractType,
                value: c.contractValue,
                date: c.contractDate,
                organ: c.organ,
              }));

              reportData.statistics.totalContracts = companyContracts.length;
              reportData.statistics.totalContractValue = companyContracts.reduce(
                (sum, c) => sum + (Number(c.contractValue) || 0),
                0
              );
              reportData.statistics.averageContractValue =
                companyContracts.length > 0
                  ? reportData.statistics.totalContractValue / companyContracts.length
                  : 0;
            }
          }
        } else if (input.entityType === "candidate") {
          const candidates_ = await db
            .select()
            .from(candidates)
            .where(eq(candidates.cpf, input.entityCpfCnpj))
            .limit(1);

          if (candidates_.length > 0) {
            const candidate = candidates_[0];
            reportData.entity = {
              type: "Candidato",
              name: candidate.name,
              cpf: candidate.cpf,
              position: candidate.position,
              party: candidate.party,
              electionYear: candidate.electionYear,
              dataSource: candidate.dataSource,
            };

            // Buscar doações do candidato
            if (input.includeDonations) {
              const candidateDonations = await db
                .select()
                .from(donations)
                .where(eq(donations.candidateId, candidate.id));

              reportData.donations = candidateDonations.map((d) => ({
                id: d.id,
                donorName: d.donorName,
                donorCpfCnpj: d.donorCpfCnpj,
                amount: d.donationAmount,
                date: d.donationDate,
              }));

              reportData.statistics.totalDonations = candidateDonations.length;
              reportData.statistics.totalDonationAmount = candidateDonations.reduce(
                (sum, d) => sum + (Number(d.donationAmount) || 0),
                0
              );
            }
          }
        }

        // Buscar alertas relacionados
        const relatedAlerts = await db
          .select()
          .from(alerts)
          .where(eq(alerts.entityCpfCnpj, input.entityCpfCnpj))
          .limit(50);

        reportData.alerts = relatedAlerts.map((a) => ({
          id: a.id,
          type: a.alertType,
          description: a.description,
          severity: a.severity,
          createdAt: a.createdAt,
        }));

        reportData.statistics.totalAlerts = relatedAlerts.length;
        reportData.statistics.highSeverityAlerts = relatedAlerts.filter(
          (a) => a.severity === "high"
        ).length;
        reportData.statistics.mediumSeverityAlerts = relatedAlerts.filter(
          (a) => a.severity === "medium"
        ).length;

        // Buscar dados de grafo se solicitado
        if (input.includeGraphData) {
          const nodes: any[] = [];
          const edges: any[] = [];
          const visited = new Set<string>();

          const addNode = (
            id: string,
            label: string,
            type: "person" | "company" | "contract",
            data: any
          ) => {
            if (!visited.has(id)) {
              visited.add(id);
              nodes.push({ id, label, type, data });
            }
          };

          const addEdge = (
            source: string,
            target: string,
            label: string,
            type: string
          ) => {
            const edgeId = `${source}-${target}`;
            if (!edges.find((e) => e.id === edgeId)) {
              edges.push({ id: edgeId, source, target, label, type });
            }
          };

          // Construir grafo similar ao getEntityGraph
          if (input.entityType === "person") {
            const servants = await db
              .select()
              .from(publicServants)
              .where(eq(publicServants.cpf, input.entityCpfCnpj))
              .limit(1);

            if (servants.length > 0) {
              const servant = servants[0];
              addNode(`person-${servant.cpf}`, servant.name || "Servidor", "person", {
                cpf: servant.cpf,
                position: servant.position,
              });

              const organContracts = await db
                .select()
                .from(contracts)
                .where(eq(contracts.organ, servant.organ || ""))
                .limit(10);

              for (const contract of organContracts) {
                addNode(
                  `contract-${contract.id}`,
                  `Contrato #${contract.id}`,
                  "contract",
                  { value: contract.contractValue }
                );
                addEdge(
                  `person-${servant.cpf}`,
                  `contract-${contract.id}`,
                  "Relacionado",
                  "related_to"
                );

                if (contract.companyId) {
                  const company = await db
                    .select()
                    .from(companies)
                    .where(eq(companies.id, contract.companyId))
                    .limit(1);

                  if (company.length > 0) {
                    addNode(
                      `company-${company[0].cnpj}`,
                      company[0].legalName || "Empresa",
                      "company",
                      { cnpj: company[0].cnpj }
                    );
                    addEdge(
                      `company-${company[0].cnpj}`,
                      `contract-${contract.id}`,
                      "Assinou",
                      "signed"
                    );
                  }
                }
              }
            }
          }

          reportData.graphData = { nodes, edges };
        }

        return { success: true, data: reportData };
      } catch (error) {
        console.error("[ReportGenerator] Erro ao gerar relatório:", error);
        return { success: false, data: null };
      }
    }),

  /**
   * Obter resumo de alertas para relatório
   */
  getAlertsSummary: publicProcedure
    .input(z.object({ entityCpfCnpj: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return { summary: {}, byType: {}, bySeverity: {} };
      }

      try {
        const relatedAlerts = await db
          .select()
          .from(alerts)
          .where(eq(alerts.entityCpfCnpj, input.entityCpfCnpj));

        const byType: Record<string, number> = {};
        const bySeverity: Record<string, number> = {};

        relatedAlerts.forEach((alert) => {
          const alertType = alert.alertType || "unknown";
          const severity = alert.severity || "low";
          byType[alertType] = (byType[alertType] || 0) + 1;
          bySeverity[severity] = (bySeverity[severity] || 0) + 1;
        });

        return {
          summary: {
            total: relatedAlerts.length,
            high: bySeverity["high"] || 0,
            medium: bySeverity["medium"] || 0,
            low: bySeverity["low"] || 0,
          },
          byType,
          bySeverity,
        };
      } catch (error) {
        console.error("[ReportGenerator] Erro ao obter resumo de alertas:", error);
        return { summary: {}, byType: {}, bySeverity: {} };
      }
    }),
});
