/**
 * Roteador de Administração
 * Procedimentos para gerenciar sincronização, cache e Neo4j
 */

import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { getSyncManager } from "../sync/syncManager";
import { getCacheManager, CACHE_KEYS } from "../cache/cacheManager";
import { loadDemoData, clearDemoData } from "../collectors/demoDataCollector";
import {
  initializeNeo4j,
  createPersonNode,
  createCompanyNode,
  createContractNode,
  createPersonContractRelationship,
  createCompanyContractRelationship,
  findPersonWithConnections,
  findCompanyWithConnections,
  calculateCentrality,
} from "../neo4j/connection";

export const adminRouter = router({
  /**
   * Iniciar sincronização manual
   */
  startSync: publicProcedure.mutation(async () => {
    const syncManager = getSyncManager();
    const results = await syncManager.startSync();

    return {
      success: true,
      results,
      message: `Sincronização concluída com ${results.length} fontes`,
    };
  }),

  /**
   * Obter status de sincronização
   */
  getSyncStatus: publicProcedure.query(() => {
    const syncManager = getSyncManager();
    return syncManager.getStatus();
  }),

  /**
   * Agendar sincronização periódica
   */
  scheduleSyncInterval: publicProcedure
    .input(z.object({ intervalMinutes: z.number().min(5).max(1440) }))
    .mutation(({ input }) => {
      const syncManager = getSyncManager();
      syncManager.scheduleSyncInterval(input.intervalMinutes);

      return {
        success: true,
        message: `Sincronização agendada a cada ${input.intervalMinutes} minutos`,
      };
    }),

  /**
   * Parar sincronização periódica
   */
  stopSyncInterval: publicProcedure.mutation(() => {
    const syncManager = getSyncManager();
    syncManager.stopSyncInterval();

    return {
      success: true,
      message: "Sincronização periódica parada",
    };
  }),

  /**
   * Obter estatísticas de cache
   */
  getCacheStats: publicProcedure.query(() => {
    const cache = getCacheManager();
    return cache.getStats();
  }),

  /**
   * Limpar cache
   */
  clearCache: publicProcedure.mutation(() => {
    const cache = getCacheManager();
    cache.clear();

    return {
      success: true,
      message: "Cache limpo com sucesso",
    };
  }),

  /**
   * Inicializar Neo4j
   */
  initializeNeo4j: publicProcedure
    .input(
      z.object({
        uri: z.string().optional(),
        username: z.string().optional(),
        password: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await initializeNeo4j(input.uri, input.username, input.password);

        return {
          success: true,
          message: "Neo4j inicializado com sucesso",
        };
      } catch (error) {
        return {
          success: false,
          message: `Erro ao inicializar Neo4j: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Criar nó de pessoa no Neo4j
   */
  createPersonNodeNeo4j: publicProcedure
    .input(
      z.object({
        cpf: z.string(),
        name: z.string(),
        position: z.string().optional(),
        organ: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await createPersonNode(input.cpf, input.name, input.position, input.organ);

        return {
          success: true,
          message: `Nó de pessoa criado: ${input.name}`,
        };
      } catch (error) {
        return {
          success: false,
          message: `Erro ao criar nó: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Criar nó de empresa no Neo4j
   */
  createCompanyNodeNeo4j: publicProcedure
    .input(
      z.object({
        cnpj: z.string(),
        legalName: z.string(),
        tradeName: z.string().optional(),
        sector: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await createCompanyNode(input.cnpj, input.legalName, input.tradeName, input.sector);

        return {
          success: true,
          message: `Nó de empresa criado: ${input.legalName}`,
        };
      } catch (error) {
        return {
          success: false,
          message: `Erro ao criar nó: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Criar nó de contrato no Neo4j
   */
  createContractNodeNeo4j: publicProcedure
    .input(
      z.object({
        contractId: z.number(),
        contractNumber: z.string(),
        value: z.string(),
        date: z.string(),
        organ: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await createContractNode(
          input.contractId,
          input.contractNumber,
          input.value,
          new Date(input.date),
          input.organ
        );

        return {
          success: true,
          message: `Nó de contrato criado: ${input.contractNumber}`,
        };
      } catch (error) {
        return {
          success: false,
          message: `Erro ao criar nó: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Criar relacionamento entre pessoa e contrato
   */
  createPersonContractRelationshipNeo4j: publicProcedure
    .input(
      z.object({
        cpf: z.string(),
        contractId: z.number(),
        relationshipType: z.string().default("RELATED_TO"),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await createPersonContractRelationship(input.cpf, input.contractId, input.relationshipType);

        return {
          success: true,
          message: "Relacionamento criado com sucesso",
        };
      } catch (error) {
        return {
          success: false,
          message: `Erro ao criar relacionamento: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Buscar pessoa e suas conexões no Neo4j
   */
  findPersonConnectionsNeo4j: publicProcedure
    .input(
      z.object({
        cpf: z.string(),
        depth: z.number().min(1).max(5).default(2),
      })
    )
    .query(async ({ input }) => {
      try {
        const result = await findPersonWithConnections(input.cpf, input.depth);

        return {
          success: true,
          data: result,
        };
      } catch (error) {
        return {
          success: false,
          data: null,
          message: `Erro ao buscar conexões: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Buscar empresa e suas conexões no Neo4j
   */
  findCompanyConnectionsNeo4j: publicProcedure
    .input(
      z.object({
        cnpj: z.string(),
        depth: z.number().min(1).max(5).default(2),
      })
    )
    .query(async ({ input }) => {
      try {
        const result = await findCompanyWithConnections(input.cnpj, input.depth);

        return {
          success: true,
          data: result,
        };
      } catch (error) {
        return {
          success: false,
          data: null,
          message: `Erro ao buscar conexões: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Calcular centralidade de um nó
   */
  calculateCentralityNeo4j: publicProcedure
    .input(z.object({ cpfCnpj: z.string() }))
    .query(async ({ input }) => {
      try {
        const result = await calculateCentrality(input.cpfCnpj);

        return {
          success: true,
          data: result,
        };
      } catch (error) {
        return {
          success: false,
          data: null,
          message: `Erro ao calcular centralidade: ${error instanceof Error ? error.message : String(error)}`,
        };
      }
    }),

  /**
   * Carregar dados de demonstração
   */
  loadDemoData: publicProcedure.mutation(async () => {
    const result = await loadDemoData();
    return result;
  }),

  /**
   * Limpar dados de demonstração
   */
  clearDemoData: publicProcedure.mutation(async () => {
    const result = await clearDemoData();
    return result;
  }),
});
