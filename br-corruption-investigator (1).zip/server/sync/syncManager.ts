/**
 * Gerenciador de Sincronização
 * Coordena a coleta de dados de múltiplas fontes
 */

import { getCacheManager, CACHE_KEYS, DEFAULT_TTL } from "../cache/cacheManager";
// import { syncTransparencyData } from "../collectors/transparencyCollector";
// import { syncTSEData } from "../collectors/tseCollector";
import { syncComprasContracts, syncComprasSuppliers } from "../collectors/comprasCollector";
import { syncAllSanctions } from "../collectors/ceisCollector";

interface SyncResult {
  source: string;
  success: boolean;
  count: number;
  errors: string[];
  duration: number; // em ms
  timestamp: Date;
}

interface SyncStatus {
  isRunning: boolean;
  lastSync: Date | null;
  nextSync: Date | null;
  results: SyncResult[];
}

class SyncManager {
  private isRunning = false;
  private lastSync: Date | null = null;
  private syncInterval: NodeJS.Timeout | null = null;
  private results: SyncResult[] = [];

  /**
   * Iniciar sincronização manual
   */
  async startSync(): Promise<SyncResult[]> {
    if (this.isRunning) {
      console.warn("[SyncManager] Sincronização já em andamento");
      return [];
    }

    this.isRunning = true;
    this.results = [];

    try {
      console.log("[SyncManager] Iniciando sincronização de dados...");

      // Sincronizar Portal da Transparência (placeholder)
      // const transparencyResult = await this.syncTransparency();
      // this.results.push(transparencyResult);

      // Sincronizar TSE (placeholder)
      // const tseResult = await this.syncTSE();
      // this.results.push(tseResult);

      // Sincronizar Compras.gov.br
      const comprasResult = await this.syncCompras();
      this.results.push(comprasResult);

      // Sincronizar CEIS/CNEP
      const ceisResult = await this.syncCEIS();
      this.results.push(ceisResult);

      this.lastSync = new Date();

      // Atualizar cache de status
      const cache = getCacheManager();
      cache.set(CACHE_KEYS.SYNC_STATUS, this.getStatus(), DEFAULT_TTL.SHORT);

      console.log("[SyncManager] Sincronização concluída");
      return this.results;
    } catch (error) {
      console.error("[SyncManager] Erro durante sincronização:", error);
      throw error;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Sincronizar Portal da Transparência (placeholder)
   */
  private async syncTransparency(): Promise<SyncResult> {
    const startTime = Date.now();
    const duration = Date.now() - startTime;

    return {
      source: "Portal da Transparência",
      success: true,
      count: 0,
      errors: [],
      duration,
      timestamp: new Date(),
    };
  }

  /**
   * Sincronizar TSE (placeholder)
   */
  private async syncTSE(): Promise<SyncResult> {
    const startTime = Date.now();
    const duration = Date.now() - startTime;

    return {
      source: "TSE",
      success: true,
      count: 0,
      errors: [],
      duration,
      timestamp: new Date(),
    };
  }

  /**
   * Sincronizar Compras.gov.br
   */
  private async syncCompras(): Promise<SyncResult> {
    const startTime = Date.now();

    try {
      const contractsResult = await syncComprasContracts();
      const suppliersResult = await syncComprasSuppliers();

      const duration = Date.now() - startTime;
      const totalCount = contractsResult.count + suppliersResult.count;
      const totalErrors = [...contractsResult.errors, ...suppliersResult.errors];

      return {
        source: "Compras.gov.br",
        success: contractsResult.success && suppliersResult.success,
        count: totalCount,
        errors: totalErrors,
        duration,
        timestamp: new Date(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      return {
        source: "Compras.gov.br",
        success: false,
        count: 0,
        errors: [error instanceof Error ? error.message : String(error)],
        duration,
        timestamp: new Date(),
      };
    }
  }

  /**
   * Sincronizar CEIS/CNEP
   */
  private async syncCEIS(): Promise<SyncResult> {
    const startTime = Date.now();

    try {
      const result = await syncAllSanctions();
      const duration = Date.now() - startTime;
      const totalCount = result.ceis.count + result.cnep.count;
      const totalErrors = [...result.ceis.errors, ...result.cnep.errors];

      return {
        source: "CEIS/CNEP",
        success: result.success,
        count: totalCount,
        errors: totalErrors,
        duration,
        timestamp: new Date(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      return {
        source: "CEIS/CNEP",
        success: false,
        count: 0,
        errors: [error instanceof Error ? error.message : String(error)],
        duration,
        timestamp: new Date(),
      };
    }
  }

  /**
   * Agendar sincronização periódica
   */
  scheduleSyncInterval(intervalMinutes: number = 60): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }

    console.log(`[SyncManager] Agendando sincronização a cada ${intervalMinutes} minutos`);

    this.syncInterval = setInterval(() => {
      this.startSync().catch((error) => {
        console.error("[SyncManager] Erro em sincronização agendada:", error);
      });
    }, intervalMinutes * 60 * 1000);

    // Executar primeira sincronização imediatamente
    this.startSync().catch((error) => {
      console.error("[SyncManager] Erro na primeira sincronização:", error);
    });
  }

  /**
   * Parar sincronização periódica
   */
  stopSyncInterval(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
      console.log("[SyncManager] Sincronização periódica parada");
    }
  }

  /**
   * Obter status de sincronização
   */
  getStatus(): SyncStatus {
    return {
      isRunning: this.isRunning,
      lastSync: this.lastSync,
      nextSync: this.syncInterval ? new Date(Date.now() + 60 * 60 * 1000) : null,
      results: this.results,
    };
  }

  /**
   * Obter últimos resultados
   */
  getLastResults(): SyncResult[] {
    return this.results;
  }

  /**
   * Limpar histórico de resultados
   */
  clearResults(): void {
    this.results = [];
  }
}

// Singleton
let syncManagerInstance: SyncManager | null = null;

export function getSyncManager(): SyncManager {
  if (!syncManagerInstance) {
    syncManagerInstance = new SyncManager();
  }
  return syncManagerInstance;
}

export function resetSyncManager(): void {
  if (syncManagerInstance) {
    syncManagerInstance.stopSyncInterval();
    syncManagerInstance = null;
  }
}
