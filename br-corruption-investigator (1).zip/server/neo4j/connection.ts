/**
 * Módulo de Conexão com Neo4j
 * Gerencia a conexão e operações com o banco de grafos
 */

// @ts-ignore
import neo4j from "neo4j";

type Driver = any;

let driver: Driver | null = null;

/**
 * Inicializar conexão com Neo4j
 */
export async function initializeNeo4j(
  uri: string = process.env.NEO4J_URI || "bolt://localhost:7687",
  username: string = process.env.NEO4J_USERNAME || "neo4j",
  password: string = process.env.NEO4J_PASSWORD || "password"
): Promise<void> {
  try {
    driver = neo4j.driver(uri, neo4j.auth.basic(username, password));
    
    // Testar conexão
    const session = driver.session();
    await session.run("RETURN 1");
    await session.close();
    
    console.log("[Neo4j] Conexão estabelecida com sucesso");
  } catch (error) {
    console.error("[Neo4j] Erro ao conectar:", error);
    throw error;
  }
}

/**
 * Obter driver Neo4j
 */
export function getDriver(): Driver | null {
  return driver;
}

/**
 * Fechar conexão com Neo4j
 */
export async function closeNeo4j(): Promise<void> {
  if (driver) {
    await driver.close();
    driver = null;
    console.log("[Neo4j] Conexão fechada");
  }
}

/**
 * Executar query no Neo4j
 */
export async function runQuery(query: string, params: Record<string, any> = {}): Promise<any[]> {
  if (!driver) {
    console.warn("[Neo4j] Driver não inicializado");
    return [];
  }

  const session = driver.session();
  try {
    const result = await session.run(query, params);
    return result.records;
  } catch (error) {
    console.error("[Neo4j] Erro ao executar query:", error);
    throw error;
  } finally {
    await session.close();
  }
}

/**
 * Criar nó de pessoa
 */
export async function createPersonNode(
  cpf: string,
  name: string,
  position?: string,
  organ?: string
): Promise<void> {
  const query = `
    MERGE (p:Person {cpf: $cpf})
    SET p.name = $name, p.position = $position, p.organ = $organ, p.updatedAt = timestamp()
    RETURN p
  `;
  
  await runQuery(query, { cpf, name, position, organ });
}

/**
 * Criar nó de empresa
 */
export async function createCompanyNode(
  cnpj: string,
  legalName: string,
  tradeName?: string,
  sector?: string
): Promise<void> {
  const query = `
    MERGE (c:Company {cnpj: $cnpj})
    SET c.legalName = $legalName, c.tradeName = $tradeName, c.sector = $sector, c.updatedAt = timestamp()
    RETURN c
  `;
  
  await runQuery(query, { cnpj, legalName, tradeName, sector });
}

/**
 * Criar nó de contrato
 */
export async function createContractNode(
  contractId: number,
  contractNumber: string,
  value: string,
  date: Date,
  organ: string
): Promise<void> {
  const query = `
    MERGE (ct:Contract {id: $contractId})
    SET ct.number = $contractNumber, ct.value = $value, ct.date = $date, ct.organ = $organ, ct.updatedAt = timestamp()
    RETURN ct
  `;
  
  await runQuery(query, {
    contractId,
    contractNumber,
    value,
    date: date.toISOString(),
    organ,
  });
}

/**
 * Criar relacionamento entre pessoa e contrato
 */
export async function createPersonContractRelationship(
  cpf: string,
  contractId: number,
  relationshipType: string = "RELATED_TO"
): Promise<void> {
  const query = `
    MATCH (p:Person {cpf: $cpf})
    MATCH (ct:Contract {id: $contractId})
    MERGE (p)-[r:${relationshipType}]->(ct)
    SET r.createdAt = timestamp()
    RETURN r
  `;
  
  await runQuery(query, { cpf, contractId });
}

/**
 * Criar relacionamento entre empresa e contrato
 */
export async function createCompanyContractRelationship(
  cnpj: string,
  contractId: number,
  relationshipType: string = "SIGNED"
): Promise<void> {
  const query = `
    MATCH (c:Company {cnpj: $cnpj})
    MATCH (ct:Contract {id: $contractId})
    MERGE (c)-[r:${relationshipType}]->(ct)
    SET r.createdAt = timestamp()
    RETURN r
  `;
  
  await runQuery(query, { cnpj, contractId });
}

/**
 * Criar relacionamento entre pessoa e empresa
 */
export async function createPersonCompanyRelationship(
  cpf: string,
  cnpj: string,
  relationshipType: string = "OWNS"
): Promise<void> {
  const query = `
    MATCH (p:Person {cpf: $cpf})
    MATCH (c:Company {cnpj: $cnpj})
    MERGE (p)-[r:${relationshipType}]->(c)
    SET r.createdAt = timestamp()
    RETURN r
  `;
  
  await runQuery(query, { cpf, cnpj });
}

/**
 * Buscar pessoa e suas conexões
 */
export async function findPersonWithConnections(cpf: string, depth: number = 2): Promise<any> {
  const query = `
    MATCH (p:Person {cpf: $cpf})
    OPTIONAL MATCH (p)-[r*1..${depth}]-(connected)
    RETURN p, collect({node: connected, relationship: r}) as connections
  `;
  
  const records = await runQuery(query, { cpf });
  return records.length > 0 ? records[0] : null;
}

/**
 * Buscar empresa e suas conexões
 */
export async function findCompanyWithConnections(cnpj: string, depth: number = 2): Promise<any> {
  const query = `
    MATCH (c:Company {cnpj: $cnpj})
    OPTIONAL MATCH (c)-[r*1..${depth}]-(connected)
    RETURN c, collect({node: connected, relationship: r}) as connections
  `;
  
  const records = await runQuery(query, { cnpj });
  return records.length > 0 ? records[0] : null;
}

/**
 * Detectar comunidades usando algoritmo de detecção
 */
export async function detectCommunities(): Promise<any[]> {
  const query = `
    CALL algo.community.louvain.stream()
    YIELD nodeId, community
    RETURN community, collect(nodeId) as members, count(*) as size
    ORDER BY size DESC
  `;
  
  try {
    const records = await runQuery(query);
    return records.map((record) => ({
      community: record.get("community"),
      members: record.get("members"),
      size: record.get("size"),
    }));
  } catch (error) {
    console.warn("[Neo4j] Algoritmo de comunidade não disponível:", error);
    return [];
  }
}

/**
 * Encontrar caminhos entre dois nós
 */
export async function findPaths(
  startCpfCnpj: string,
  endCpfCnpj: string,
  maxLength: number = 5
): Promise<any[]> {
  const query = `
    MATCH p = shortestPath(
      (start)-[*1..${maxLength}]-(end)
    )
    WHERE (start.cpf = $startId OR start.cnpj = $startId)
      AND (end.cpf = $endId OR end.cnpj = $endId)
    RETURN p, length(p) as pathLength
    ORDER BY pathLength ASC
    LIMIT 10
  `;
  
  const records = await runQuery(query, { startId: startCpfCnpj, endId: endCpfCnpj });
  return records.map((record) => ({
    path: record.get("p"),
    length: record.get("pathLength"),
  }));
}

/**
 * Calcular centralidade de um nó
 */
export async function calculateCentrality(cpfCnpj: string): Promise<any> {
  const query = `
    MATCH (n)
    WHERE n.cpf = $id OR n.cnpj = $id
    OPTIONAL MATCH (n)-[r]-(connected)
    RETURN n, count(connected) as degree, count(r) as relationships
  `;
  
  const records = await runQuery(query, { id: cpfCnpj });
  return records.length > 0
    ? {
        node: records[0].get("n"),
        degree: records[0].get("degree"),
        relationships: records[0].get("relationships"),
      }
    : null;
}

/**
 * Limpar banco de dados (apenas para desenvolvimento)
 */
export async function clearDatabase(): Promise<void> {
  const query = "MATCH (n) DETACH DELETE n";
  await runQuery(query);
  console.log("[Neo4j] Banco de dados limpo");
}
