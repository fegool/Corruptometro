/**
 * Gerenciador de Cache
 * Implementa cache em memória para dados coletados
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number; // Time to live em segundos
}

class CacheManager {
  private cache: Map<string, CacheEntry<any>> = new Map();
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor() {
    // Iniciar limpeza automática a cada 5 minutos
    this.startCleanup();
  }

  /**
   * Obter valor do cache
   */
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    // Verificar se expirou
    const now = Date.now();
    const age = (now - entry.timestamp) / 1000; // em segundos

    if (age > entry.ttl) {
      this.cache.delete(key);
      return null;
    }

    return entry.data as T;
  }

  /**
   * Armazenar valor no cache
   */
  set<T>(key: string, data: T, ttlSeconds: number = 3600): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlSeconds,
    });
  }

  /**
   * Verificar se chave existe e está válida
   */
  has(key: string): boolean {
    const entry = this.cache.get(key);

    if (!entry) {
      return false;
    }

    const now = Date.now();
    const age = (now - entry.timestamp) / 1000;

    if (age > entry.ttl) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  /**
   * Deletar valor do cache
   */
  delete(key: string): void {
    this.cache.delete(key);
  }

  /**
   * Limpar todo o cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Obter estatísticas do cache
   */
  getStats(): {
    size: number;
    keys: string[];
    memoryUsage: number;
  } {
    const keys = Array.from(this.cache.keys());
    let memoryUsage = 0;

    this.cache.forEach((entry) => {
      memoryUsage += JSON.stringify(entry.data).length;
    });

    return {
      size: this.cache.size,
      keys,
      memoryUsage,
    };
  }

  /**
   * Iniciar limpeza automática
   */
  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      let cleaned = 0;

      this.cache.forEach((entry, key) => {
        const age = (now - entry.timestamp) / 1000;
        if (age > entry.ttl) {
          this.cache.delete(key);
          cleaned++;
        }
      });

      if (cleaned > 0) {
        console.log(`[CacheManager] Limpeza automática: ${cleaned} entradas removidas`);
      }
    }, 5 * 60 * 1000); // A cada 5 minutos
  }

  /**
   * Parar limpeza automática
   */
  stopCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  /**
   * Destruir cache
   */
  destroy(): void {
    this.stopCleanup();
    this.clear();
  }
}

// Singleton
let cacheInstance: CacheManager | null = null;

export function getCacheManager(): CacheManager {
  if (!cacheInstance) {
    cacheInstance = new CacheManager();
  }
  return cacheInstance;
}

export function resetCache(): void {
  if (cacheInstance) {
    cacheInstance.destroy();
    cacheInstance = null;
  }
}

// Chaves de cache padrão
export const CACHE_KEYS = {
  SERVANTS_BY_CPF: (cpf: string) => `servants:${cpf}`,
  SERVANTS_BY_ORGAN: (organ: string) => `servants:organ:${organ}`,
  COMPANIES_BY_CNPJ: (cnpj: string) => `companies:${cnpj}`,
  CONTRACTS_BY_ORGAN: (organ: string) => `contracts:organ:${organ}`,
  CANDIDATES_BY_CPF: (cpf: string) => `candidates:${cpf}`,
  ALERTS_BY_ENTITY: (cpfCnpj: string) => `alerts:${cpfCnpj}`,
  GRAPH_DATA: (cpfCnpj: string) => `graph:${cpfCnpj}`,
  SYNC_STATUS: "sync:status",
  LAST_SYNC_TRANSPARENCY: "sync:transparency:last",
  LAST_SYNC_TSE: "sync:tse:last",
  LAST_SYNC_COMPRAS: "sync:compras:last",
  LAST_SYNC_CEIS: "sync:ceis:last",
};

// TTL padrão (em segundos)
export const DEFAULT_TTL = {
  SHORT: 5 * 60, // 5 minutos
  MEDIUM: 30 * 60, // 30 minutos
  LONG: 2 * 60 * 60, // 2 horas
  VERY_LONG: 24 * 60 * 60, // 24 horas
};
