# Investigador de Corrupção Política Brasil - TODO

## Fase 1: Pesquisa e Arquitetura
- [x] Pesquisar APIs públicas brasileiras
- [x] Documentar endpoints e autenticação
- [x] Definir schema do banco de dados MySQL
- [x] Definir estrutura de grafos Neo4j

## Fase 2: Backend - Coletores de Dados
- [x] Implementar coletor Portal da Transparência (servidores, contratos, licitações, PEPs)
- [x] Implementar coletor TSE (candidatos, doações, bens)
- [ ] Implementar coletor Compras.gov.br
- [ ] Implementar coletor CEIS/CNEP/CEPIM
- [ ] Implementar sistema de cache e atualização de dados
- [ ] Criar testes para coletores

## Fase 3: Backend - Banco de Dados
- [x] Criar tabelas MySQL para servidores
- [x] Criar tabelas MySQL para contratos e licitações
- [x] Criar tabelas MySQL para empresas/fornecedores
- [x] Criar tabelas MySQL para candidatos e doações
- [x] Criar tabelas MySQL para relacionamentos
- [x] Implementar índices e otimizações

## Fase 4: Backend - Grafos Neo4j
- [ ] Configurar conexão Neo4j
- [ ] Criar nós para pessoas (CPF)
- [ ] Criar nós para empresas (CNPJ)
- [ ] Criar nós para contratos
- [ ] Criar relacionamentos entre nós
- [ ] Implementar queries de análise de grafos

## Fase 5: Backend - Detecção de Padrões
- [x] Implementar detecção de duplo vínculo público-privado (estrutura)
- [x] Implementar detecção de funcionários fantasmas
- [x] Implementar detecção de contratos com valores anormais
- [x] Implementar detecção de bens declarados anormais
- [x] Implementar sistema de alertas

## Fase 6: Backend - API tRPC
- [x] Implementar procedimento de busca por CPF/CNPJ
- [x] Implementar procedimento de detalhes de servidor
- [x] Implementar procedimento de detalhes de empresa
- [x] Implementar procedimento de listagem de alertas
- [x] Implementar procedimento de estatísticas

## Fase 7: Frontend - Dashboard
- [x] Criar layout principal do dashboard
- [x] Implementar estatísticas gerais
- [x] Implementar sistema de busca por CPF/CNPJ
- [ ] Criar visualizações de grafos
- [ ] Implementar filtros e busca avançada

## Fase 8: Frontend - Relatórios
- [ ] Implementar geração de relatórios em PDF
- [ ] Incluir evidências e conexões nos relatórios
- [ ] Implementar exportação de dados

## Fase 9: Documentação
- [x] Documentar instalação e configuração
- [x] Documentar uso do sistema
- [x] Criar guia de APIs
- [x] Criar exemplos de investigações
- [x] Documentação técnica completa

## Fase 10: Testes e Validação
- [ ] Testes unitários dos coletores
- [ ] Testes de integração
- [ ] Testes de performance
- [ ] Validação de dados

## Fase 11: Entrega
- [ ] Revisão final
- [ ] Checkpoint final
- [ ] Entrega ao usuário

## Fase 12: Visualização de Grafos
- [x] Instalar Cytoscape.js e dependências
- [x] Criar componente GraphVisualization.tsx
- [x] Adicionar página de visualização de grafos
- [x] Integrar busca com visualização de grafos
- [x] Adicionar filtros e controles de zoom
- [ ] Implementar procedimento tRPC para buscar dados de grafos do banco


## Fase 13: Busca Funcional e Integração com Dados Reais
- [x] Criar procedimento tRPC para buscar grafos do banco de dados
- [x] Implementar busca por CPF/CNPJ/nome com resultados
- [x] Criar página de resultados com detalhes de entidade
- [x] Conectar busca do dashboard com resultados
- [x] Exibir alertas e padrões suspeitos nos resultados
- [ ] Implementar filtros de busca avançados
- [ ] Adicionar paginação nos resultados


## Fase 14: Geração de Relatórios em PDF
- [x] Criar procedimento tRPC para gerar relatórios em PDF
- [x] Implementar template de relatório com evidências
- [x] Criar botão de exportação na página de resultados
- [x] Integrar ReportExporter com dados de entidade
- [x] Formatação profissional de PDF
- [ ] Adicionar gráficos e visualizações ao PDF
- [ ] Testar geração de PDF com dados reais


## Fase 15: Coletores Adicionais e Cache
- [x] Implementar coletor Compras.gov.br
- [x] Implementar coletor CEIS/CNEP/CEPIM
- [x] Implementar sistema de cache em memória
- [x] Criar sistema de sincronização de dados
- [x] Adicionar logs de sincronização
- [ ] Criar testes unitários para coletores

## Fase 16: Integração Neo4j
- [x] Instalar driver Neo4j
- [x] Configurar conexão com Neo4j
- [x] Criar nós para pessoas (CPF)
- [x] Criar nós para empresas (CNPJ)
- [x] Criar nós para contratos
- [x] Criar relacionamentos entre nós
- [x] Implementar queries de análise de grafos
- [x] Adicionar cálculo de centralidade
- [x] Criar roteador tRPC para admin (sincronização e Neo4j)


## Fase 17: Sistema de Alertas em Tempo Real
- [ ] Criar tabela de notificações no banco de dados
- [ ] Implementar detector de conexões suspeitas
- [ ] Criar sistema de notificações em tempo real (WebSocket)
- [ ] Implementar armazenamento de histórico de alertas
- [ ] Criar roteador tRPC para gerenciar notificações
- [ ] Adicionar painel de alertas na interface
- [ ] Implementar filtros e busca de alertas
- [ ] Adicionar configurações de preferências de notificação


## Fase 18: Dashboard de Administração
- [x] Criar página de admin com layout de dashboard
- [x] Exibir status de sincronização em tempo real
- [x] Mostrar estatísticas de cache
- [x] Gerenciar conexões Neo4j
- [x] Botão para iniciar sincronização manual
- [x] Visualizar histórico de sincronizações
- [x] Botão para carregar dados de demonstração

## Fase 19: Dados Públicos Sem API
- [x] Documentar quais APIs requerem chaves (API_KEYS_GUIDE.md)
- [x] Criar modo de demonstração com dados de exemplo
- [x] Coletor de dados de demonstração (demoDataCollector.ts)
- [x] Procedimentos tRPC para carregar/limpar dados de demo
- [ ] Testar carregamento de dados de demo no dashboard
