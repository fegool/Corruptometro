# Guia de APIs e Dados Públicos

Este documento descreve quais APIs requerem autenticação e quais dados estão disponíveis publicamente sem necessidade de chaves.

## 📊 Dados Públicos SEM Autenticação (Implementados)

### 1. Portal da Transparência - Dados Públicos
**URL Base:** `https://www.portaldatransparencia.gov.br/api-de-dados`

**Endpoints Disponíveis (sem autenticação):**
- `/servidores` - Servidores públicos federais
- `/contratos` - Contratos públicos
- `/licitacoes` - Licitações
- `/diarias` - Diárias de viagens
- `/despesas` - Despesas públicas

**Status:** ✅ Implementado em `transparencyCollector.ts`

**Exemplo de Uso:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/servidores?pagina=1&tamanhoPagina=100"
```

---

### 2. TSE - Dados Eleitorais
**URL Base:** `https://dadosabertos.tse.jus.br`

**Dados Disponíveis (CSV/JSON):**
- Candidatos por eleição
- Doações de campanha
- Bens declarados
- Resultados eleitorais

**Status:** ✅ Implementado em `tseCollector.ts`

**Como Acessar:**
```bash
# Candidatos 2024
curl "https://dadosabertos.tse.jus.br/dataset/candidatos-2024/download"

# Doações 2024
curl "https://dadosabertos.tse.jus.br/dataset/doacoes-2024/download"
```

---

### 3. Compras.gov.br - Dados de Contratações
**URL Base:** `https://www.compras.gov.br/api`

**Endpoints Públicos:**
- `/contratos` - Contratos públicos
- `/fornecedores` - Fornecedores registrados
- `/licitacoes` - Licitações

**Status:** ✅ Implementado em `comprasCollector.ts`

**Exemplo:**
```bash
curl "https://www.compras.gov.br/api/contratos?pagina=1&limite=100"
```

---

### 4. CEIS - Cadastro de Empresas Inidôneas
**URL Base:** `https://www.portaldatransparencia.gov.br/api-de-dados/ceis`

**Dados:** Empresas impedidas de contratar com governo

**Status:** ✅ Implementado em `ceisCollector.ts`

**Exemplo:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/ceis?pagina=1"
```

---

### 5. CNEP - Cadastro Nacional de Empresas Punidas
**URL Base:** `https://www.portaldatransparencia.gov.br/api-de-dados/cnep`

**Dados:** Pessoas e empresas com sanções administrativas

**Status:** ✅ Implementado em `ceisCollector.ts`

**Exemplo:**
```bash
curl "https://www.portaldatransparencia.gov.br/api-de-dados/cnep?pagina=1"
```

---

### 6. Receita Federal - Dados de CNPJ
**URL Base:** `https://www.receitafederal.gov.br`

**Dados Disponíveis:**
- Informações básicas de CNPJ (público)
- Natureza jurídica
- Atividade econômica
- Situação cadastral

**Status:** 🔄 Pode ser coletado via web scraping ou APIs alternativas

**Alternativa Gratuita:**
```bash
# Via API alternativa (minha.receita.net.br)
curl "https://minha.receita.net.br/api/cnpj/[CNPJ]"
```

---

### 7. Banco Central - Dados Públicos
**URL Base:** `https://www.bcb.gov.br/api`

**Dados:** Taxas de câmbio, índices econômicos

**Status:** 🔄 Disponível para análise de contexto econômico

---

## 🔐 APIs com Autenticação Obrigatória

### 1. Portal da Transparência - Dados Sensíveis
**Requer:** Token de API

**Como Obter:**
1. Acesse: https://www.portaldatransparencia.gov.br/api-de-dados
2. Solicite um token de desenvolvedor
3. Tempo de aprovação: 1-3 dias úteis

**Endpoints Protegidos:**
- `/servidores/detalhes` - Informações detalhadas de servidores
- `/contratos/detalhes` - Detalhes completos de contratos
- `/viagens` - Dados de viagens de autoridades

**Variável de Ambiente:** `TRANSPARENCY_API_TOKEN`

---

### 2. Google Maps API (Opcional)
**Para:** Visualização de localidades, endereços

**Como Obter:**
1. Acesse: https://console.cloud.google.com
2. Ative Google Maps JavaScript API
3. Crie uma chave de API

**Variável de Ambiente:** `GOOGLE_MAPS_API_KEY`

**Status:** ✅ Já integrado no template (usa proxy Manus)

---

### 3. APIs Externas Opcionais

#### OpenAI / Claude (para análise de IA)
**Para:** Análise automática de padrões suspeitos

**Como Obter:**
- OpenAI: https://platform.openai.com/api-keys
- Anthropic: https://console.anthropic.com

**Variável de Ambiente:** `OPENAI_API_KEY` ou `ANTHROPIC_API_KEY`

**Status:** 🔄 Pode ser integrado para análise automática

---

## 🚀 Dados de Demonstração

Para testar o sistema sem APIs externas, use dados de exemplo:

### Dados de Teste Inclusos
```typescript
// Servidor público de exemplo
{
  cpf: "12345678901",
  name: "João da Silva",
  organ: "Ministério da Fazenda",
  position: "Analista de Sistemas",
  salary: "15000.00",
  admissionDate: "2015-03-15"
}

// Empresa de exemplo
{
  cnpj: "12345678000190",
  legalName: "Empresa Teste LTDA",
  sector: "Tecnologia"
}

// Contrato de exemplo
{
  contractNumber: "2024-001",
  organ: "Ministério da Educação",
  contractValue: "500000.00",
  contractDate: "2024-01-15"
}
```

---

## 📋 Configuração Recomendada

### Ambiente de Desenvolvimento (Sem APIs)
```bash
# .env.local
TRANSPARENCY_API_TOKEN=demo_mode
TSE_DATA_MODE=local_cache
COMPRAS_API_MODE=local_cache
```

### Ambiente de Produção (Com APIs)
```bash
# .env.production
TRANSPARENCY_API_TOKEN=seu_token_aqui
PORTAL_DA_TRANSPARENCIA_API_KEY=sua_chave_aqui
GOOGLE_MAPS_API_KEY=sua_chave_aqui
```

---

## 🔄 Fluxo de Coleta de Dados

```
┌─────────────────────────────────────────┐
│   Sistema de Investigação               │
└─────────────────────────────────────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
    ┌────────┐ ┌────────┐ ┌────────┐
    │ Portal │ │  TSE   │ │Compras │
    │Transpa │ │ Dados  │ │.gov.br │
    │rência  │ │Eleitor │ │        │
    └────────┘ └────────┘ └────────┘
        │           │           │
        └───────────┼───────────┘
                    │
                    ▼
            ┌──────────────┐
            │  Cache Mem   │
            │  (TTL 1-24h) │
            └──────────────┘
                    │
                    ▼
            ┌──────────────┐
            │ MySQL DB     │
            │ (Persistente)│
            └──────────────┘
                    │
                    ▼
            ┌──────────────┐
            │  Neo4j Grafos│
            │  (Análise)   │
            └──────────────┘
                    │
                    ▼
            ┌──────────────┐
            │ Detecção de  │
            │ Padrões      │
            └──────────────┘
```

---

## 📞 Suporte e Documentação

### Links Úteis
- [Portal da Transparência - API](https://www.portaldatransparencia.gov.br/api-de-dados)
- [TSE - Dados Abertos](https://dadosabertos.tse.jus.br)
- [Compras.gov.br - API](https://www.compras.gov.br/api)
- [Receita Federal - CNPJ](https://www.receitafederal.gov.br)

### Próximos Passos
1. ✅ Testar com dados públicos (já implementado)
2. 🔄 Solicitar token do Portal da Transparência (opcional)
3. 🔄 Configurar Google Maps (opcional)
4. 🔄 Integrar IA para análise automática (opcional)

---

**Última atualização:** Março 2026
**Versão:** 1.0
