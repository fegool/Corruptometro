import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Redirecionar para dashboard
    setLocation("/dashboard");
  }, [setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-white mb-4">Carregando...</h1>
        <p className="text-slate-400">Aguarde enquanto carregamos o sistema</p>
      </div>
    </div>
  );
}
