import { useState } from "react";

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Investigador de Corrupção Política
          </h1>
          <p className="text-slate-400">
            Sistema de análise de dados públicos para detecção de irregularidades
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8 p-6 bg-slate-800 border border-slate-700 rounded-lg">
          <h2 className="text-xl font-bold text-white mb-4">Buscar Entidade</h2>
          <p className="text-slate-400 mb-4">Pesquise por CPF, CNPJ ou nome</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              console.log("Buscando:", searchQuery);
            }}
            className="flex gap-4"
          >
            <input
              type="text"
              placeholder="Digite CPF, CNPJ ou nome..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 text-white placeholder:text-slate-400 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <select className="px-4 py-2 bg-slate-700 border border-slate-600 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all">Todos</option>
              <option value="cpf">CPF</option>
              <option value="cnpj">CNPJ</option>
            </select>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-colors"
            >
              Buscar
            </button>
          </form>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <div className="p-6 bg-slate-800 border border-slate-700 rounded-lg">
            <h3 className="text-sm font-medium text-slate-300 mb-2">
              Servidores Públicos
            </h3>
            <div className="text-2xl font-bold text-white">0</div>
            <p className="text-xs text-slate-400 mt-1">Registrados no sistema</p>
          </div>

          <div className="p-6 bg-slate-800 border border-slate-700 rounded-lg">
            <h3 className="text-sm font-medium text-slate-300 mb-2">Empresas</h3>
            <div className="text-2xl font-bold text-white">0</div>
            <p className="text-xs text-slate-400 mt-1">Fornecedoras</p>
          </div>

          <div className="p-6 bg-slate-800 border border-slate-700 rounded-lg">
            <h3 className="text-sm font-medium text-slate-300 mb-2">Contratos</h3>
            <div className="text-2xl font-bold text-white">0</div>
            <p className="text-xs text-slate-400 mt-1">Públicos</p>
          </div>

          <div className="p-6 bg-slate-800 border border-slate-700 rounded-lg">
            <h3 className="text-sm font-medium text-slate-300 mb-2">Candidatos</h3>
            <div className="text-2xl font-bold text-white">0</div>
            <p className="text-xs text-slate-400 mt-1">Eleitorais</p>
          </div>

          <div className="p-6 bg-red-900/30 border border-red-700 rounded-lg">
            <h3 className="text-sm font-medium text-red-300 mb-2">Alertas</h3>
            <div className="text-2xl font-bold text-red-400">0</div>
            <p className="text-xs text-red-300 mt-1">Irregularidades</p>
          </div>
        </div>

        {/* Info Section */}
        <div className="p-6 bg-slate-800 border border-slate-700 rounded-lg">
          <h2 className="text-xl font-bold text-white mb-2">Bem-vindo ao Sistema</h2>
          <p className="text-slate-400 mb-4">
            Use a barra de busca acima para investigar servidores públicos, empresas e candidatos
          </p>
          <p className="text-slate-300 mb-6">
            Este sistema integra dados de múltiplas fontes públicas brasileiras para identificar padrões suspeitos de corrupção e conflitos de interesse.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-slate-700 rounded-lg">
              <h3 className="font-semibold text-white mb-2">Portal da Transparência</h3>
              <p className="text-sm text-slate-400">Servidores, contratos e licitações federais</p>
            </div>
            <div className="p-4 bg-slate-700 rounded-lg">
              <h3 className="font-semibold text-white mb-2">TSE</h3>
              <p className="text-sm text-slate-400">Candidatos, doações e bens declarados</p>
            </div>
            <div className="p-4 bg-slate-700 rounded-lg">
              <h3 className="font-semibold text-white mb-2">Análise Inteligente</h3>
              <p className="text-sm text-slate-400">Detecção automática de padrões suspeitos</p>
            </div>
          </div>
          <a
            href="/graph"
            className="inline-block px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors"
          >
            📊 Visualizar Grafos de Conexões
          </a>
        </div>
      </div>
    </div>
  );
}
