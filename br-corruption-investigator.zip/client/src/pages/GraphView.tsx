import { useState } from "react";
import { GraphVisualization } from "@/components/GraphVisualization";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface GraphNode {
  id: string;
  label: string;
  type: "person" | "company" | "contract";
  data?: Record<string, any>;
}

interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  type: "works_for" | "owns" | "signed" | "related_to";
}

export default function GraphView() {
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Dados de exemplo para demonstração
  const exampleData = {
    nodes: [
      {
        id: "person-1",
        label: "João Silva",
        type: "person" as const,
        data: { cpf: "123.456.789-00", position: "Secretário" },
      },
      {
        id: "person-2",
        label: "Maria Santos",
        type: "person" as const,
        data: { cpf: "987.654.321-11", position: "Vereadora" },
      },
      {
        id: "company-1",
        label: "Tech Solutions Ltda",
        type: "company" as const,
        data: { cnpj: "12.345.678/0001-90", sector: "Tecnologia" },
      },
      {
        id: "company-2",
        label: "Construções Brasil",
        type: "company" as const,
        data: { cnpj: "98.765.432/0001-11", sector: "Construção" },
      },
      {
        id: "contract-1",
        label: "Contrato #2024-001",
        type: "contract" as const,
        data: { value: "R$ 500.000", date: "2024-01-15" },
      },
      {
        id: "contract-2",
        label: "Contrato #2024-002",
        type: "contract" as const,
        data: { value: "R$ 1.200.000", date: "2024-02-20" },
      },
    ],
    edges: [
      {
        id: "edge-1",
        source: "person-1",
        target: "company-1",
        label: "Sócio",
        type: "owns" as const,
      },
      {
        id: "edge-2",
        source: "person-2",
        target: "company-2",
        label: "Parente",
        type: "related_to" as const,
      },
      {
        id: "edge-3",
        source: "company-1",
        target: "contract-1",
        label: "Assinou",
        type: "signed" as const,
      },
      {
        id: "edge-4",
        source: "company-2",
        target: "contract-2",
        label: "Assinou",
        type: "signed" as const,
      },
      {
        id: "edge-5",
        source: "person-1",
        target: "contract-1",
        label: "Beneficiário",
        type: "related_to" as const,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Visualização de Conexões</h1>
          <p className="text-slate-400">
            Explore as redes de relacionamento entre políticos, empresas e contratos
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Graph */}
          <div className="lg:col-span-3">
            <Card className="bg-slate-800 border-slate-700 h-[600px]">
              <CardHeader className="pb-3">
                <CardTitle className="text-white">Grafo de Conexões</CardTitle>
                <CardDescription>Clique em um nó para ver detalhes</CardDescription>
              </CardHeader>
              <CardContent className="h-[calc(100%-80px)]">
                <GraphVisualization data={exampleData} onNodeClick={setSelectedNode} />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Search */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white">Buscar Nó</CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  placeholder="Nome ou ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                />
              </CardContent>
            </Card>

            {/* Node Details */}
            {selectedNode ? (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-white">Detalhes do Nó</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Nome</p>
                    <p className="text-white font-semibold">{selectedNode.label}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Tipo</p>
                    <div className="inline-block px-2 py-1 rounded text-xs font-medium">
                      {selectedNode.type === "person" && (
                        <span className="bg-blue-500/20 text-blue-300">Pessoa</span>
                      )}
                      {selectedNode.type === "company" && (
                        <span className="bg-green-500/20 text-green-300">Empresa</span>
                      )}
                      {selectedNode.type === "contract" && (
                        <span className="bg-amber-500/20 text-amber-300">Contrato</span>
                      )}
                    </div>
                  </div>
                  {selectedNode.data && Object.keys(selectedNode.data).length > 0 && (
                    <div>
                      <p className="text-xs text-slate-400 mb-2">Informações</p>
                      <div className="space-y-2">
                        {Object.entries(selectedNode.data).map(([key, value]) => (
                          <div key={key} className="text-xs">
                            <p className="text-slate-400 capitalize">{key}:</p>
                            <p className="text-slate-200 font-mono">{String(value)}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <Button
                    className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                    size="sm"
                  >
                    Ver Detalhes Completos
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-white">Detalhes do Nó</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">
                    Clique em um nó no grafo para ver seus detalhes
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Statistics */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white">Estatísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <p className="text-xs text-slate-400">Nós</p>
                  <p className="text-lg font-bold text-white">{exampleData.nodes.length}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Conexões</p>
                  <p className="text-lg font-bold text-white">{exampleData.edges.length}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Pessoas</p>
                  <p className="text-lg font-bold text-blue-400">
                    {exampleData.nodes.filter((n) => n.type === "person").length}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Empresas</p>
                  <p className="text-lg font-bold text-green-400">
                    {exampleData.nodes.filter((n) => n.type === "company").length}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
