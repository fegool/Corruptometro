import { useEffect, useRef, useState } from "react";
import cytoscape, { Core, ElementDefinition } from "cytoscape";
// @ts-ignore - No type definitions available
import COSEBilkent from "cytoscape-cose-bilkent";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, RefreshCw } from "lucide-react";

// Register the layout algorithm
cytoscape.use(COSEBilkent);

interface GraphNode {
  id: string;
  label: string;
  type: "person" | "company" | "contract";
  data?: Record<string, any>;
}

interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  type: "works_for" | "owns" | "signed" | "related_to";
}

interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

interface GraphVisualizationProps {
  data: GraphData;
  onNodeClick?: (node: GraphNode) => void;
}

export function GraphVisualization({ data, onNodeClick }: GraphVisualizationProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!containerRef.current || !data.nodes.length) {
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);

      // Convert data to Cytoscape format
      const elements: ElementDefinition[] = [
        ...data.nodes.map((node) => ({
          data: {
            id: node.id,
            label: node.label,
            type: node.type,
            ...node.data,
          },
        })),
        ...data.edges.map((edge) => ({
          data: {
            id: edge.id,
            source: edge.source,
            target: edge.target,
            label: edge.label,
            type: edge.type,
          },
        })),
      ];

      // Initialize Cytoscape
      const cy = cytoscape({
        container: containerRef.current,
        elements,
        style: [
          {
            selector: "node",
            style: {
              "background-color": (ele) => {
                const type = ele.data("type");
                if (type === "person") return "#3b82f6"; // blue
                if (type === "company") return "#10b981"; // green
                if (type === "contract") return "#f59e0b"; // amber
                return "#6b7280"; // gray
              },
              label: "data(label)",
              "text-valign": "center",
              "text-halign": "center",
              "font-size": 12,
              color: "#ffffff",
              "border-width": 2,
              "border-color": "#1f2937",
              width: "60px",
              height: "60px",
              padding: "10px",
            },
          },
          {
            selector: "node:selected",
            style: {
              "border-width": 3,
              "border-color": "#fbbf24",
            },
          },
          {
            selector: "edge",
            style: {
              "line-color": (ele) => {
                const type = ele.data("type");
                if (type === "works_for") return "#3b82f6";
                if (type === "owns") return "#10b981";
                if (type === "signed") return "#f59e0b";
                if (type === "related_to") return "#ef4444";
                return "#9ca3af";
              },
              "target-arrow-color": (ele) => {
                const type = ele.data("type");
                if (type === "works_for") return "#3b82f6";
                if (type === "owns") return "#10b981";
                if (type === "signed") return "#f59e0b";
                if (type === "related_to") return "#ef4444";
                return "#9ca3af";
              },
              "target-arrow-shape": "triangle",
              "curve-style": "bezier",
              width: 2,
              "text-background-color": "#1f2937",
              "text-background-opacity": 0.8,
              "text-background-padding": "4px",
              label: "data(label)",
              "font-size": 10,
              color: "#ffffff",
            },
          },
          {
            selector: "edge:selected",
            style: {
              width: 3,
            },
          },
        ],
        layout: {
          name: "cose-bilkent",
          randomize: false,
          fit: true,
          padding: 50,
          nodeDimensionsIncludeLabels: true,
        } as any,
      });

      // Handle node clicks
      cy.on("tap", "node", (evt) => {
        const node = evt.target;
        const nodeData: GraphNode = {
          id: node.id(),
          label: node.data("label"),
          type: node.data("type"),
          data: node.data(),
        };
        onNodeClick?.(nodeData);
      });

      cyRef.current = cy;
      setIsLoading(false);
    } catch (error) {
      console.error("Error initializing Cytoscape:", error);
      setIsLoading(false);
    }

    return () => {
      if (cyRef.current) {
        cyRef.current.destroy();
        cyRef.current = null;
      }
    };
  }, [data, onNodeClick]);

  const handleZoomIn = () => {
    if (cyRef.current) {
      cyRef.current.zoom(cyRef.current.zoom() * 1.2);
    }
  };

  const handleZoomOut = () => {
    if (cyRef.current) {
      cyRef.current.zoom(cyRef.current.zoom() / 1.2);
    }
  };

  const handleFit = () => {
    if (cyRef.current) {
      cyRef.current.fit(cyRef.current.elements(), 50);
    }
  };

  return (
    <div className="relative w-full h-full bg-slate-800 rounded-lg overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-800/50 z-10">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mb-2"></div>
            <p className="text-slate-300">Carregando grafo...</p>
          </div>
        </div>
      )}

      <div ref={containerRef} className="w-full h-full" />

      {/* Controls */}
      <div className="absolute top-4 right-4 flex gap-2 z-20">
        <Button
          size="sm"
          variant="outline"
          onClick={handleZoomIn}
          className="bg-slate-700 border-slate-600 hover:bg-slate-600"
          title="Aumentar zoom"
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={handleZoomOut}
          className="bg-slate-700 border-slate-600 hover:bg-slate-600"
          title="Diminuir zoom"
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={handleFit}
          className="bg-slate-700 border-slate-600 hover:bg-slate-600"
          title="Ajustar à tela"
        >
          <RefreshCw className="w-4 h-4" />
        </Button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-slate-700/90 p-4 rounded-lg text-sm z-20">
        <h3 className="font-semibold text-white mb-3">Legenda</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-blue-500"></div>
            <span className="text-slate-300">Pessoa</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-green-500"></div>
            <span className="text-slate-300">Empresa</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-amber-500"></div>
            <span className="text-slate-300">Contrato</span>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-slate-600 space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-0.5 bg-blue-500"></div>
            <span className="text-slate-300 text-xs">Trabalha em</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-0.5 bg-green-500"></div>
            <span className="text-slate-300 text-xs">Possui</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-0.5 bg-amber-500"></div>
            <span className="text-slate-300 text-xs">Assinou</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-0.5 bg-red-500"></div>
            <span className="text-slate-300 text-xs">Relacionado</span>
          </div>
        </div>
      </div>
    </div>
  );
}
