/**
 * Coletor de dados do TSE (Tribunal Superior Eleitoral)
 * Processa arquivos CSV do Portal de Dados Abertos do TSE
 * - Candidatos
 * - Doações de campanha
 * - Bens declarados
 */

import axios from "axios";
import { parse } from "csv-parse/sync";
import { eq } from "drizzle-orm";
import { getDb } from "../db";
import { candidates, donations } from "../../drizzle/schema";

interface TSEConfig {
  baseUrl?: string;
  electionYear?: number;
}

interface CandidateCSVRow {
  SQ_CANDIDATO: string;
  NM_CANDIDATO: string;
  NR_CPF: string;
  SG_UF: string;
  NM_PARTIDO: string;
  DS_CARGO: string;
  VL_BENS_CANDIDATO: string;
}

interface DonationCSVRow {
  SQ_DOADOR: string;
  NM_DOADOR: string;
  CPF_CNPJ_DOADOR: string;
  SQ_CANDIDATO: string;
  NM_CANDIDATO: string;
  VL_RECEITA: string;
  DT_RECEITA: string;
}

export class TSECollector {
  private baseUrl: string;
  private electionYear: number;

  constructor(config: TSEConfig = {}) {
    this.baseUrl = config.baseUrl || "https://dadosabertos.tse.jus.br/dataset";
    this.electionYear = config.electionYear || new Date().getFullYear();
  }

  /**
   * Coleta dados de candidatos do TSE
   */
  async collectCandidates(): Promise<void> {
    console.log(`[TSECollector] Iniciando coleta de candidatos ${this.electionYear}...`);

    try {
      const db = await getDb();
      if (!db) {
        console.error("[TSECollector] Banco de dados não disponível");
        return;
      }

      // URL do arquivo CSV de candidatos
      const candidatesUrl = `https://dadosabertos.tse.jus.br/dataset/candidatos-${this.electionYear}/resource/candidatos-${this.electionYear}.csv`;

      console.log(`[TSECollector] Baixando arquivo de candidatos...`);
      const response = await axios.get(candidatesUrl, {
        timeout: 60000,
        responseType: "arraybuffer",
      });

      // Parse CSV
      const csvData = response.data.toString("utf-8");
      const records: CandidateCSVRow[] = parse(csvData, {
        columns: true,
        skip_empty_lines: true,
        encoding: "utf-8",
      });

      console.log(`[TSECollector] Processando ${records.length} candidatos...`);

      let totalInserted = 0;

      for (const record of records) {
        try {
          if (!record.NR_CPF || !record.NM_CANDIDATO) {
            continue;
          }

          const declaredAssets = record.VL_BENS_CANDIDATO
            ? String(Number(record.VL_BENS_CANDIDATO.replace(/[^\d.-]/g, "")))
            : "0";

          await db
            .insert(candidates)
            .values({
              cpf: record.NR_CPF.replace(/[^\d]/g, ""),
              name: record.NM_CANDIDATO,
              party: record.NM_PARTIDO,
              position: record.DS_CARGO,
              state: record.SG_UF,
              electionYear: this.electionYear,
              declaredAssets: declaredAssets,
              dataSource: "tse",
            })
            .onDuplicateKeyUpdate({
              set: {
                name: record.NM_CANDIDATO,
                party: record.NM_PARTIDO,
                position: record.DS_CARGO,
                declaredAssets: declaredAssets,
              },
            });

          totalInserted++;
        } catch (error) {
          console.warn(`[TSECollector] Erro ao inserir candidato:`, error);
        }
      }

      console.log(
        `[TSECollector] Coleta de candidatos concluída. Total inserido: ${totalInserted}`
      );
    } catch (error) {
      console.error("[TSECollector] Erro ao coletar candidatos:", error);
    }
  }

  /**
   * Coleta dados de doações de campanha do TSE
   */
  async collectDonations(): Promise<void> {
    console.log(`[TSECollector] Iniciando coleta de doações ${this.electionYear}...`);

    try {
      const db = await getDb();
      if (!db) {
        console.error("[TSECollector] Banco de dados não disponível");
        return;
      }

      // URL do arquivo CSV de doações
      const donationsUrl = `https://dadosabertos.tse.jus.br/dataset/doacoes-${this.electionYear}/resource/doacoes-${this.electionYear}.csv`;

      console.log(`[TSECollector] Baixando arquivo de doações...`);
      const response = await axios.get(donationsUrl, {
        timeout: 60000,
        responseType: "arraybuffer",
      });

      // Parse CSV
      const csvData = response.data.toString("utf-8");
      const records: DonationCSVRow[] = parse(csvData, {
        columns: true,
        skip_empty_lines: true,
        encoding: "utf-8",
      });

      console.log(`[TSECollector] Processando ${records.length} doações...`);

      let totalInserted = 0;

      for (const record of records) {
        try {
          if (!record.CPF_CNPJ_DOADOR || !record.VL_RECEITA) {
            continue;
          }

          const donationAmount = String(
            Number(record.VL_RECEITA.replace(/[^\d.-]/g, ""))
          );
          const donationDate = record.DT_RECEITA
            ? new Date(record.DT_RECEITA)
            : new Date();

          // Encontrar candidato pelo nome
          const candidateRecord = await db
            .select()
            .from(candidates)
            .where(eq(candidates.name, record.NM_CANDIDATO))
            .limit(1);

          const candidateId = candidateRecord.length > 0 ? candidateRecord[0].id : undefined;

          await db.insert(donations).values({
            donorCpfCnpj: record.CPF_CNPJ_DOADOR.replace(/[^\d]/g, ""),
            donorName: record.NM_DOADOR,
            candidateId: candidateId,
            donationAmount: donationAmount,
            donationDate: donationDate,
            electionYear: this.electionYear,
            dataSource: "tse",
          });

          totalInserted++;
        } catch (error) {
          console.warn(`[TSECollector] Erro ao inserir doação:`, error);
        }
      }

      console.log(
        `[TSECollector] Coleta de doações concluída. Total inserido: ${totalInserted}`
      );
    } catch (error) {
      console.error("[TSECollector] Erro ao coletar doações:", error);
    }
  }
}

/**
 * Função auxiliar para criar e executar coleta
 */
export async function runTSECollection(electionYear?: number): Promise<void> {
  const collector = new TSECollector({
    electionYear,
  });

  await collector.collectCandidates();
  await collector.collectDonations();

  console.log("[TSECollector] Coleta completa!");
}
