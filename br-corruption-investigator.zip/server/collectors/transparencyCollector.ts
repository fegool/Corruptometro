/**
 * Coletor de dados do Portal da Transparência
 * Integra-se com a API do Portal da Transparência para coletar dados de:
 * - Servidores públicos
 * - Contratos
 * - Licitações
 * - Pessoas Expostas Politicamente (PEPs)
 */

import axios, { AxiosInstance } from "axios";
import { getDb } from "../db";
import { publicServants, companies, contracts, alerts } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

interface TransparencyConfig {
  apiToken: string;
  baseUrl?: string;
}

interface PublicServantData {
  idServidorAposentadoPensionista: number;
  nome: string;
  cpf: string;
  orgao: string;
  cargo: string;
  remuneracao: number;
  dataAdmissao: string;
}

interface ContractData {
  id: number;
  numero: string;
  cnpjFornecedor: string;
  nomeFornecedor: string;
  orgao: string;
  valor: number;
  dataAssinatura: string;
  tipo: string;
  status: string;
}

export class TransparencyCollector {
  private client: AxiosInstance;
  private apiToken: string;

  constructor(config: TransparencyConfig) {
    this.apiToken = config.apiToken;
    this.client = axios.create({
      baseURL: config.baseUrl || "https://api.portaldatransparencia.gov.br",
      timeout: 30000,
      headers: {
        "User-Agent": "CorruptionInvestigator/1.0",
      },
    });
  }

  /**
   * Coleta dados de servidores públicos
   */
  async collectPublicServants(limit: number = 1000): Promise<void> {
    console.log("[TransparencyCollector] Iniciando coleta de servidores públicos...");
    
    try {
      const db = await getDb();
      if (!db) {
        console.error("[TransparencyCollector] Banco de dados não disponível");
        return;
      }

      let page = 1;
      let totalCollected = 0;

      while (totalCollected < limit) {
        try {
          const response = await this.client.get("/api-de-dados/servidores", {
            params: {
              pagina: page,
              quantidade: 100,
              token: this.apiToken,
            },
          });

          const servants: PublicServantData[] = response.data || [];

          if (servants.length === 0) {
            break;
          }

          for (const servant of servants) {
            try {
              const salaryStr = servant.remuneracao ? String(Number(servant.remuneracao)) : "0";
              const admissionDate = servant.dataAdmissao 
                ? new Date(servant.dataAdmissao) 
                : new Date();

              await db
                .insert(publicServants)
                .values({
                  cpf: servant.cpf,
                  name: servant.nome,
                  organ: servant.orgao,
                  position: servant.cargo,
                  salary: salaryStr,
                  admissionDate: admissionDate,
                  dataSource: "portal-transparencia",
                })
                .onDuplicateKeyUpdate({
                  set: {
                    name: servant.nome,
                    organ: servant.orgao,
                    position: servant.cargo,
                    salary: salaryStr,
                  },
                });

              totalCollected++;
            } catch (error) {
              console.warn(
                `[TransparencyCollector] Erro ao inserir servidor ${servant.cpf}:`,
                error
              );
            }
          }

          page++;

          // Respeitar limite de requisições da API
          await new Promise((resolve) => setTimeout(resolve, 700));
        } catch (error) {
          console.error(
            `[TransparencyCollector] Erro ao coletar página ${page}:`,
            error
          );
          break;
        }
      }

      console.log(
        `[TransparencyCollector] Coleta de servidores concluída. Total: ${totalCollected}`
      );
    } catch (error) {
      console.error("[TransparencyCollector] Erro geral na coleta de servidores:", error);
    }
  }

  /**
   * Coleta dados de contratos públicos
   */
  async collectContracts(limit: number = 1000): Promise<void> {
    console.log("[TransparencyCollector] Iniciando coleta de contratos...");

    try {
      const db = await getDb();
      if (!db) {
        console.error("[TransparencyCollector] Banco de dados não disponível");
        return;
      }

      let page = 1;
      let totalCollected = 0;

      while (totalCollected < limit) {
        try {
          const response = await this.client.get("/api-de-dados/contratos", {
            params: {
              pagina: page,
              quantidade: 100,
              token: this.apiToken,
            },
          });

          const contractList: ContractData[] = response.data || [];

          if (contractList.length === 0) {
            break;
          }

          for (const contractData of contractList) {
            try {
              // Primeiro, inserir ou atualizar a empresa
              let companyId: number | undefined = undefined;

              if (contractData.cnpjFornecedor) {
                const existingCompany = await db
                  .select()
                  .from(companies)
                  .where(eq(companies.cnpj, contractData.cnpjFornecedor))
                  .limit(1);

                if (existingCompany.length > 0) {
                  companyId = existingCompany[0].id;
                } else {
                  const insertResult = await db.insert(companies).values({
                    cnpj: contractData.cnpjFornecedor,
                    legalName: contractData.nomeFornecedor,
                    dataSource: "portal-transparencia",
                  });

                  companyId = (insertResult as any).insertId;
                }
              }

              // Inserir contrato
              const contractValue = contractData.valor ? String(Number(contractData.valor)) : "0";
              const contractDate = contractData.dataAssinatura
                ? new Date(contractData.dataAssinatura)
                : new Date();

              await db
                .insert(contracts)
                .values({
                  contractNumber: contractData.numero || undefined,
                  companyId: companyId,
                  organ: contractData.orgao,
                  contractValue: contractValue,
                  contractDate: contractDate,
                  contractType: contractData.tipo,
                  status: contractData.status,
                  dataSource: "portal-transparencia",
                })
                .onDuplicateKeyUpdate({
                  set: {
                    status: contractData.status,
                    contractValue: contractValue,
                  },
                });

              totalCollected++;
            } catch (error) {
              console.warn(
                `[TransparencyCollector] Erro ao inserir contrato ${contractData.numero}:`,
                error
              );
            }
          }

          page++;
          await new Promise((resolve) => setTimeout(resolve, 700));
        } catch (error) {
          console.error(
            `[TransparencyCollector] Erro ao coletar página ${page}:`,
            error
          );
          break;
        }
      }

      console.log(
        `[TransparencyCollector] Coleta de contratos concluída. Total: ${totalCollected}`
      );
    } catch (error) {
      console.error("[TransparencyCollector] Erro geral na coleta de contratos:", error);
    }
  }

  /**
   * Coleta dados de Pessoas Expostas Politicamente (PEPs)
   */
  async collectPEPs(): Promise<void> {
    console.log("[TransparencyCollector] Iniciando coleta de PEPs...");

    try {
      const response = await this.client.get("/api-de-dados/peps", {
        params: {
          token: this.apiToken,
        },
      });

      const peps = response.data || [];
      console.log(`[TransparencyCollector] Encontrados ${peps.length} PEPs`);

      // Aqui você pode processar os PEPs conforme necessário
      // Por exemplo, marcá-los como pessoas de interesse especial

      return peps;
    } catch (error) {
      console.error("[TransparencyCollector] Erro ao coletar PEPs:", error);
    }
  }
}

/**
 * Função auxiliar para criar e executar coleta
 */
export async function runTransparencyCollection(apiToken: string): Promise<void> {
  const collector = new TransparencyCollector({
    apiToken,
  });

  // Coletar dados em ordem de prioridade
  await collector.collectPublicServants(5000);
  await collector.collectContracts(5000);
  await collector.collectPEPs();

  console.log("[TransparencyCollector] Coleta completa!");
}
