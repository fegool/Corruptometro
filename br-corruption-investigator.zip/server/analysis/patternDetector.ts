/**
 * Motor de Detecção de Padrões
 * Identifica padrões suspeitos de corrupção:
 * - Duplo vínculo público-privado
 * - Funcionários fantasmas
 * - Contratos com parentes
 * - Padrões de fraude
 */

import { getDb } from "../db";
import { publicServants, companies, contracts, candidates, donations, alerts } from "../../drizzle/schema";
import { eq, and, gte, lte } from "drizzle-orm";

export class PatternDetector {
  /**
   * Detecta pessoas com duplo vínculo público-privado
   * (trabalham em órgão público e possuem empresa que recebe contratos)
   */
  async detectDualBinding(): Promise<void> {
    console.log("[PatternDetector] Detectando duplo vínculo público-privado...");

    try {
      const db = await getDb();
      if (!db) {
        console.error("[PatternDetector] Banco de dados não disponível");
        return;
      }

      // Buscar todos os servidores públicos
      const servants = await db.select().from(publicServants);

      for (const servant of servants) {
        // Buscar contratos onde o CPF do servidor aparece como proprietário
        // Isso seria um relacionamento que precisaria ser estabelecido
        // Por enquanto, apenas log
        console.log(`[PatternDetector] Verificando servidor: ${servant.name} (${servant.cpf})`);
      }

      console.log("[PatternDetector] Detecção de duplo vínculo concluída");
    } catch (error) {
      console.error("[PatternDetector] Erro ao detectar duplo vínculo:", error);
    }
  }

  /**
   * Detecta funcionários fantasmas
   * (pessoas com remuneração muito baixa ou registros duplicados)
   */
  async detectGhostEmployees(): Promise<void> {
    console.log("[PatternDetector] Detectando funcionários fantasmas...");

    try {
      const db = await getDb();
      if (!db) {
        console.error("[PatternDetector] Banco de dados não disponível");
        return;
      }

      // Buscar servidores com remuneração zero ou muito baixa
      const servants = await db.select().from(publicServants);

      const ghostEmployees = servants.filter((s) => {
        const salary = s.salary ? Number(s.salary) : 0;
        return salary === 0 || salary < 100;
      });

      console.log(
        `[PatternDetector] Encontrados ${ghostEmployees.length} funcionários fantasmas`
      );

      // Criar alertas para cada funcionário fantasma
      for (const employee of ghostEmployees) {
        try {
          await db.insert(alerts).values({
            alertType: "ghost-employee",
            description: `Funcionário fantasma detectado: ${employee.name} com remuneração ${employee.salary}`,
            severity: "medium",
            entityCpfCnpj: employee.cpf,
          });
        } catch (error) {
          console.warn("[PatternDetector] Erro ao criar alerta:", error);
        }
      }

      console.log("[PatternDetector] Detecção de funcionários fantasmas concluída");
    } catch (error) {
      console.error("[PatternDetector] Erro ao detectar funcionários fantasmas:", error);
    }
  }

  /**
   * Detecta contratos com valores anormalmente altos
   */
  async detectAnomalousContracts(): Promise<void> {
    console.log("[PatternDetector] Detectando contratos com valores anormais...");

    try {
      const db = await getDb();
      if (!db) {
        console.error("[PatternDetector] Banco de dados não disponível");
        return;
      }

      // Buscar todos os contratos
      const allContracts = await db.select().from(contracts);

      // Calcular valor médio
      const totalValue = allContracts.reduce((sum, c) => {
        const value = c.contractValue ? Number(c.contractValue) : 0;
        return sum + value;
      }, 0);

      const avgValue = totalValue / (allContracts.length || 1);
      const stdDev = Math.sqrt(
        allContracts.reduce((sum, c) => {
          const value = c.contractValue ? Number(c.contractValue) : 0;
          return sum + Math.pow(value - avgValue, 2);
        }, 0) / (allContracts.length || 1)
      );

      // Contratos com valor > média + 2 * desvio padrão são considerados anormais
      const anomalousContracts = allContracts.filter((c) => {
        const value = c.contractValue ? Number(c.contractValue) : 0;
        return value > avgValue + 2 * stdDev;
      });

      console.log(
        `[PatternDetector] Encontrados ${anomalousContracts.length} contratos com valores anormais`
      );

      // Criar alertas
      for (const contract of anomalousContracts) {
        try {
          await db.insert(alerts).values({
            alertType: "anomalous-contract",
            description: `Contrato com valor anormalmente alto: R$ ${contract.contractValue}`,
            severity: "high",
            entityCpfCnpj: contract.companyId?.toString(),
          });
        } catch (error) {
          console.warn("[PatternDetector] Erro ao criar alerta:", error);
        }
      }

      console.log("[PatternDetector] Detecção de contratos anormais concluída");
    } catch (error) {
      console.error("[PatternDetector] Erro ao detectar contratos anormais:", error);
    }
  }

  /**
   * Detecta candidatos com bens declarados anormalmente altos
   */
  async detectAnomalousAssets(): Promise<void> {
    console.log("[PatternDetector] Detectando bens declarados anormais...");

    try {
      const db = await getDb();
      if (!db) {
        console.error("[PatternDetector] Banco de dados não disponível");
        return;
      }

      // Buscar todos os candidatos
      const allCandidates = await db.select().from(candidates);

      // Calcular valor médio de bens
      const totalAssets = allCandidates.reduce((sum, c) => {
        const assets = c.declaredAssets ? Number(c.declaredAssets) : 0;
        return sum + assets;
      }, 0);

      const avgAssets = totalAssets / (allCandidates.length || 1);
      const stdDev = Math.sqrt(
        allCandidates.reduce((sum, c) => {
          const assets = c.declaredAssets ? Number(c.declaredAssets) : 0;
          return sum + Math.pow(assets - avgAssets, 2);
        }, 0) / (allCandidates.length || 1)
      );

      // Candidatos com bens > média + 3 * desvio padrão são considerados anormais
      const anomalousAssets = allCandidates.filter((c) => {
        const assets = c.declaredAssets ? Number(c.declaredAssets) : 0;
        return assets > avgAssets + 3 * stdDev;
      });

      console.log(
        `[PatternDetector] Encontrados ${anomalousAssets.length} candidatos com bens anormais`
      );

      // Criar alertas
      for (const candidate of anomalousAssets) {
        try {
          await db.insert(alerts).values({
            alertType: "anomalous-assets",
            description: `Candidato ${candidate.name} com bens declarados anormalmente altos: R$ ${candidate.declaredAssets}`,
            severity: "medium",
            entityCpfCnpj: candidate.cpf,
          });
        } catch (error) {
          console.warn("[PatternDetector] Erro ao criar alerta:", error);
        }
      }

      console.log("[PatternDetector] Detecção de bens anormais concluída");
    } catch (error) {
      console.error("[PatternDetector] Erro ao detectar bens anormais:", error);
    }
  }

  /**
   * Executa todas as detecções de padrão
   */
  async runAllDetections(): Promise<void> {
    console.log("[PatternDetector] Iniciando todas as detecções...");

    await this.detectGhostEmployees();
    await this.detectAnomalousContracts();
    await this.detectAnomalousAssets();
    await this.detectDualBinding();

    console.log("[PatternDetector] Todas as detecções concluídas!");
  }
}

/**
 * Função auxiliar para executar detecções
 */
export async function runPatternDetection(): Promise<void> {
  const detector = new PatternDetector();
  await detector.runAllDetections();
}
