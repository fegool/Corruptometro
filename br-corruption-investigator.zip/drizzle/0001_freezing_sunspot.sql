CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alert_type` varchar(100) NOT NULL,
	`description` text,
	`severity` varchar(20),
	`entity_cpf_cnpj` varchar(14),
	`related_entities` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`resolved` boolean DEFAULT false,
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `candidates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cpf` varchar(11) NOT NULL,
	`name` varchar(255) NOT NULL,
	`party` varchar(100),
	`position` varchar(100),
	`state` varchar(2),
	`election_year` int,
	`declared_assets` decimal(15,2),
	`data_source` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `candidates_id` PRIMARY KEY(`id`),
	CONSTRAINT `candidates_cpf_unique` UNIQUE(`cpf`)
);
--> statement-breakpoint
CREATE TABLE `companies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cnpj` varchar(14) NOT NULL,
	`legal_name` varchar(255) NOT NULL,
	`trade_name` varchar(255),
	`sector` varchar(100),
	`founded_date` date,
	`data_source` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companies_id` PRIMARY KEY(`id`),
	CONSTRAINT `companies_cnpj_unique` UNIQUE(`cnpj`)
);
--> statement-breakpoint
CREATE TABLE `contracts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contract_number` varchar(50),
	`company_id` int,
	`organ` varchar(255),
	`contract_value` decimal(15,2),
	`contract_date` date,
	`contract_type` varchar(100),
	`status` varchar(50),
	`data_source` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contracts_id` PRIMARY KEY(`id`),
	CONSTRAINT `contracts_contract_number_unique` UNIQUE(`contract_number`)
);
--> statement-breakpoint
CREATE TABLE `donations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`donor_cpf_cnpj` varchar(14),
	`donor_name` varchar(255),
	`candidate_id` int,
	`donation_amount` decimal(15,2),
	`donation_date` date,
	`election_year` int,
	`data_source` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `donations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `public_servants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cpf` varchar(11) NOT NULL,
	`name` varchar(255) NOT NULL,
	`organ` varchar(255),
	`position` varchar(255),
	`salary` decimal(12,2),
	`admission_date` date,
	`data_source` varchar(50),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `public_servants_id` PRIMARY KEY(`id`),
	CONSTRAINT `public_servants_cpf_unique` UNIQUE(`cpf`)
);
--> statement-breakpoint
CREATE TABLE `relationships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`source_type` varchar(50),
	`source_id` varchar(50),
	`target_type` varchar(50),
	`target_id` varchar(50),
	`relationship_type` varchar(100),
	`relationship_strength` int DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_alert_type` ON `alerts` (`alert_type`);--> statement-breakpoint
CREATE INDEX `idx_severity` ON `alerts` (`severity`);--> statement-breakpoint
CREATE INDEX `idx_entity` ON `alerts` (`entity_cpf_cnpj`);--> statement-breakpoint
CREATE INDEX `idx_cpf` ON `candidates` (`cpf`);--> statement-breakpoint
CREATE INDEX `idx_party` ON `candidates` (`party`);--> statement-breakpoint
CREATE INDEX `idx_state` ON `candidates` (`state`);--> statement-breakpoint
CREATE INDEX `idx_cnpj` ON `companies` (`cnpj`);--> statement-breakpoint
CREATE INDEX `idx_company_id` ON `contracts` (`company_id`);--> statement-breakpoint
CREATE INDEX `idx_organ` ON `contracts` (`organ`);--> statement-breakpoint
CREATE INDEX `idx_contract_date` ON `contracts` (`contract_date`);--> statement-breakpoint
CREATE INDEX `idx_donor` ON `donations` (`donor_cpf_cnpj`);--> statement-breakpoint
CREATE INDEX `idx_candidate_id` ON `donations` (`candidate_id`);--> statement-breakpoint
CREATE INDEX `idx_donation_date` ON `donations` (`donation_date`);--> statement-breakpoint
CREATE INDEX `idx_cpf` ON `public_servants` (`cpf`);--> statement-breakpoint
CREATE INDEX `idx_organ` ON `public_servants` (`organ`);--> statement-breakpoint
CREATE INDEX `idx_source` ON `relationships` (`source_type`,`source_id`);--> statement-breakpoint
CREATE INDEX `idx_target` ON `relationships` (`target_type`,`target_id`);--> statement-breakpoint
CREATE INDEX `idx_relationship_type` ON `relationships` (`relationship_type`);