import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, boolean, index } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Investigation System Tables

/**
 * Servidores Públicos - Servidores do Poder Executivo Federal
 */
export const publicServants = mysqlTable(
  "public_servants",
  {
    id: int("id").autoincrement().primaryKey(),
    cpf: varchar("cpf", { length: 11 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    organ: varchar("organ", { length: 255 }),
    position: varchar("position", { length: 255 }),
    salary: decimal("salary", { precision: 12, scale: 2 }),
    admissionDate: date("admission_date"),
    dataSource: varchar("data_source", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    cpfIdx: index("idx_cpf").on(table.cpf),
    organIdx: index("idx_organ").on(table.organ),
  })
);

export type PublicServant = typeof publicServants.$inferSelect;
export type InsertPublicServant = typeof publicServants.$inferInsert;

/**
 * Empresas/Fornecedores - Empresas que recebem contratos públicos
 */
export const companies = mysqlTable(
  "companies",
  {
    id: int("id").autoincrement().primaryKey(),
    cnpj: varchar("cnpj", { length: 14 }).notNull().unique(),
    legalName: varchar("legal_name", { length: 255 }).notNull(),
    tradeName: varchar("trade_name", { length: 255 }),
    sector: varchar("sector", { length: 100 }),
    foundedDate: date("founded_date"),
    dataSource: varchar("data_source", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    cnpjIdx: index("idx_cnpj").on(table.cnpj),
  })
);

export type Company = typeof companies.$inferSelect;
export type InsertCompany = typeof companies.$inferInsert;

/**
 * Contratos Públicos - Contratos entre órgãos públicos e fornecedores
 */
export const contracts = mysqlTable(
  "contracts",
  {
    id: int("id").autoincrement().primaryKey(),
    contractNumber: varchar("contract_number", { length: 50 }).unique(),
    companyId: int("company_id"),
    organ: varchar("organ", { length: 255 }),
    contractValue: decimal("contract_value", { precision: 15, scale: 2 }).default("0"),
    contractDate: date("contract_date"),
    contractType: varchar("contract_type", { length: 100 }),
    status: varchar("status", { length: 50 }),
    dataSource: varchar("data_source", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    companyIdIdx: index("idx_company_id").on(table.companyId),
    organIdx: index("idx_organ").on(table.organ),
    contractDateIdx: index("idx_contract_date").on(table.contractDate),
  })
);

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = typeof contracts.$inferInsert;

/**
 * Candidatos Eleitorais - Candidatos nas eleições
 */
export const candidates = mysqlTable(
  "candidates",
  {
    id: int("id").autoincrement().primaryKey(),
    cpf: varchar("cpf", { length: 11 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    party: varchar("party", { length: 100 }),
    position: varchar("position", { length: 100 }),
    state: varchar("state", { length: 2 }),
    electionYear: int("election_year"),
    declaredAssets: decimal("declared_assets", { precision: 15, scale: 2 }),
    dataSource: varchar("data_source", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    cpfIdx: index("idx_cpf").on(table.cpf),
    partyIdx: index("idx_party").on(table.party),
    stateIdx: index("idx_state").on(table.state),
  })
);

export type Candidate = typeof candidates.$inferSelect;
export type InsertCandidate = typeof candidates.$inferInsert;

/**
 * Doações de Campanha - Doações para campanhas eleitorais
 */
export const donations = mysqlTable(
  "donations",
  {
    id: int("id").autoincrement().primaryKey(),
    donorCpfCnpj: varchar("donor_cpf_cnpj", { length: 14 }),
    donorName: varchar("donor_name", { length: 255 }),
    candidateId: int("candidate_id"),
    donationAmount: decimal("donation_amount", { precision: 15, scale: 2 }),
    donationDate: date("donation_date"),
    electionYear: int("election_year"),
    dataSource: varchar("data_source", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    donorIdx: index("idx_donor").on(table.donorCpfCnpj),
    candidateIdIdx: index("idx_candidate_id").on(table.candidateId),
    donationDateIdx: index("idx_donation_date").on(table.donationDate),
  })
);

export type Donation = typeof donations.$inferSelect;
export type InsertDonation = typeof donations.$inferInsert;

/**
 * Alertas de Irregularidades - Alertas gerados pelo motor de detecção
 */
export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    alertType: varchar("alert_type", { length: 100 }).notNull(),
    description: text("description"),
    severity: varchar("severity", { length: 20 }),
    entityCpfCnpj: varchar("entity_cpf_cnpj", { length: 14 }),
    relatedEntities: text("related_entities"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    resolved: boolean("resolved").default(false),
  },
  (table) => ({
    alertTypeIdx: index("idx_alert_type").on(table.alertType),
    severityIdx: index("idx_severity").on(table.severity),
    entityIdx: index("idx_entity").on(table.entityCpfCnpj),
  })
);

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

/**
 * Relacionamentos - Relacionamentos entre entidades
 */
export const relationships = mysqlTable(
  "relationships",
  {
    id: int("id").autoincrement().primaryKey(),
    sourceType: varchar("source_type", { length: 50 }),
    sourceId: varchar("source_id", { length: 50 }),
    targetType: varchar("target_type", { length: 50 }),
    targetId: varchar("target_id", { length: 50 }),
    relationshipType: varchar("relationship_type", { length: 100 }),
    relationshipStrength: int("relationship_strength").default(1),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    sourceIdx: index("idx_source").on(table.sourceType, table.sourceId),
    targetIdx: index("idx_target").on(table.targetType, table.targetId),
    relationshipTypeIdx: index("idx_relationship_type").on(table.relationshipType),
  })
);

export type Relationship = typeof relationships.$inferSelect;
export type InsertRelationship = typeof relationships.$inferInsert;